---
name: spanish-reviewer
description: Review and correct Spanish user-facing text in frontend components, pages, forms, API-visible messages, and UX copy. Use this skill whenever the user asks to fix Spanish spelling, grammar, accents, punctuation, tone, labels, placeholders, validation messages, toasts, empty states, headings, buttons, or any UI copy for Spanish-speaking users. Prefer formal Latin American Spanish with a Chilean institutional tone, and proactively use it for frontend text review even if the user only says "review the copy", "fix ortografia", "revisar textos", "correct Spanish", or "make the UI text sound right".
---

# Spanish Reviewer

Correct Spanish user-facing text while preserving code behavior.

The target voice is formal Latin American Spanish, preferably Chilean, suitable for an academic or institutional product. Use `usted` where direct address is needed, avoid slang, and keep copy clear, concise, and natural for UI.

## Default behavior

When the user asks to review or correct Spanish text, fix the issues directly unless they explicitly request a report-only review.

After editing, respond with:

```text
Changed files:
- path/to/file
- path/to/other-file

I can show the detailed text changes if you want.
```

If no files needed changes, say that no user-facing Spanish text changes were needed and mention the files checked.

## What to review

Focus on text users can see or hear:

- headings, page titles, section titles, descriptions, and helper text
- buttons, links, tabs, breadcrumbs, menu items, and table headers
- form labels, placeholders, validation messages, and error text
- empty states, loading states, success messages, warnings, and toasts
- `aria-label`, `title`, `alt`, and other accessibility text
- API response messages that are displayed directly to users
- seeded or constant UI labels when they are part of the product experience

Do not spend time on internal-only identifiers unless they leak into the UI.

## Code safety

Preserve behavior and structure. Spanish copy review should not become a refactor.

- Do not rename variables, functions, routes, props, enum values, query keys, CSS classes, test IDs, database fields, or translation keys just because their names are in Spanish.
- Do not change JSX expressions, interpolation placeholders, template variables, or format tokens such as `{name}`, `${termName}`, `%s`, `{{count}}`, or date/time patterns.
- Do not change imported symbols or object keys unless the key itself is displayed as user-facing text.
- Keep capitalization style consistent with the surrounding UI.
- Keep punctuation compatible with the component context. For short labels and buttons, prefer no final period.
- Preserve existing product terminology unless it is clearly misspelled or grammatically wrong.

When a phrase has both code meaning and UI meaning, prefer the smallest safe text-only edit. If safety is unclear, ask before changing it.

## Spanish style rules

Prefer formal, neutral, Chilean institutional Spanish:

- Use `usted` for direct instructions: `Ingrese`, `Seleccione`, `Revise`, `Confirme`.
- Prefer `iniciar sesión` over `loguearse` or `login` when visible to users.
- Prefer `correo electrónico` over `email` unless the product already uses `email` consistently.
- Prefer `período académico`, `defensa`, `inscripción`, `evaluación`, `comisión`, and `acta` when those match the domain.
- Use correct accents: `período`, `académico`, `inscripción`, `evaluación`, `contraseña`, `también`, `está`, `aún`, `solo` when needed by current RAE norms or clarity.
- Use opening question and exclamation marks when writing full sentences: `¿Desea continuar?`, `¡Listo!`.
- Avoid `vosotros`, slang, and region-specific colloquialisms that would feel informal in a university system.
- Avoid nonstandard inclusive forms such as `alumnxs`, `tod@s`, or `estudiantes/as` unless the user explicitly requests them. Prefer neutral collective wording such as `estudiantes`, `personas usuarias`, or rewriting the sentence.
- Keep messages concise. UI copy should help the user act, not explain implementation details.

## Common corrections

Use these as examples, not as a fixed glossary:

| Avoid                                          | Prefer                                                     |
| ---------------------------------------------- | ---------------------------------------------------------- |
| `Ingrese su mail`                              | `Ingrese su correo electrónico`                            |
| `Seleccione el periodo academico`              | `Seleccione el período académico`                          |
| `No hay defensas disponbiles`                  | `No hay defensas disponibles`                              |
| `Estas seguro de continuar?`                   | `¿Está seguro de que desea continuar?`                     |
| `La inscripcion fue actualizado`               | `La inscripción fue actualizada`                           |
| `Error al cargar los datos, intente mas tarde` | `Error al cargar los datos. Intente nuevamente más tarde.` |
| `Los alumnos deben subir su informe`           | `Los estudiantes deben subir su informe`                   |

## Workflow

1. Identify candidate files with user-facing text. In this repository, start with `app/`, `components/`, `lib/const/`, `lib/types/`, and API routes under `app/api/` when responses are visible to users.
2. Inspect the surrounding component or route before editing so you understand whether a string is UI copy, a key, or an internal value.
3. Apply minimal text-only edits.
4. If files were changed, run a lightweight check when appropriate for the touched files. Prefer `npm run lint` only when the edit touches TypeScript/React files and the user has not asked for a very quick pass.
5. Summarize changed files and ask whether the user wants detailed changes.

## Output detail on request

If the user asks to see details after the summary, show a concise list of before/after text changes grouped by file. Do not dump full diffs unless the user specifically asks for a diff.

Use this format:

```text
path/to/file.tsx
- "Old text" -> "New text"
- "Old text with {value}" -> "New text with {value}"
```
