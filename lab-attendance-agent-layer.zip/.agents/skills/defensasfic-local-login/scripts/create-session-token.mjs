import { createRequire } from 'node:module';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

function fail(message) {
  process.stderr.write(`${message}\n`);
  process.exit(1);
}

function readRequiredEnvironment(name) {
  const value = process.env[name]?.trim();
  if (!value) {
    fail(`${name} is required.`);
  }
  return value;
}

function isLoopbackHostname(hostname) {
  return (
    hostname === 'localhost' ||
    hostname === '127.0.0.1' ||
    hostname === '[::1]' ||
    hostname.endsWith('.localhost')
  );
}

const baseUrlValue = readRequiredEnvironment('AUTHJS_BASE_URL');
let baseUrl;
try {
  baseUrl = new URL(baseUrlValue);
} catch {
  fail('AUTHJS_BASE_URL must be a valid absolute URL.');
}

if (!isLoopbackHostname(baseUrl.hostname)) {
  fail('Refusing to mint a session for a non-loopback hostname.');
}

if (baseUrl.protocol !== 'http:' && baseUrl.protocol !== 'https:') {
  fail('AUTHJS_BASE_URL must use HTTP or HTTPS.');
}

const secret = readRequiredEnvironment('AUTHJS_SECRET');
if (secret.length < 32) {
  fail('AUTHJS_SECRET must contain at least 32 characters.');
}

const cookieName =
  process.env.AUTHJS_COOKIE_NAME?.trim() ||
  (baseUrl.protocol === 'https:'
    ? '__Secure-authjs.session-token'
    : 'authjs.session-token');

const tokenJson = readRequiredEnvironment('AUTHJS_TOKEN_JSON');
let token;
try {
  token = JSON.parse(tokenJson);
} catch {
  fail('AUTHJS_TOKEN_JSON must be valid JSON.');
}

if (token === null || Array.isArray(token) || typeof token !== 'object') {
  fail('AUTHJS_TOKEN_JSON must describe an object.');
}

if (!Number.isInteger(token.userId) || token.userId <= 0) {
  fail('AUTHJS_TOKEN_JSON.userId must be a positive integer.');
}

const maxAgeValue = process.env.AUTHJS_MAX_AGE_SECONDS?.trim() || '3600';
const maxAge = Number(maxAgeValue);
if (!Number.isInteger(maxAge) || maxAge < 60 || maxAge > 86400) {
  fail('AUTHJS_MAX_AGE_SECONDS must be an integer from 60 through 86400.');
}

const projectPackageJsonUrl = pathToFileURL(
  path.resolve(process.cwd(), 'package.json'),
);
const requireFromProject = createRequire(projectPackageJsonUrl);
let jwtModulePath;
try {
  jwtModulePath = requireFromProject.resolve('next-auth/jwt');
} catch {
  fail('Could not resolve next-auth/jwt from the current working directory.');
}

const { decode, encode } = await import(pathToFileURL(jwtModulePath).href);
const sessionToken = await encode({
  token,
  secret,
  salt: cookieName,
  maxAge,
});
const decodedToken = await decode({
  token: sessionToken,
  secret,
  salt: cookieName,
});

if (decodedToken?.userId !== token.userId) {
  fail('The generated Auth.js session token failed self-verification.');
}

process.stdout.write(sessionToken);
