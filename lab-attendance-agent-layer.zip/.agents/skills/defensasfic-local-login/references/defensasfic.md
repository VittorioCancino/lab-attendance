# DefensasFIC local authentication reference

Verify these details against the current branch before every run. They document
the repository state observed when this skill was created, not a permanent API.

## Authentication mapping

- `lib/auth/auth.ts` configures Auth.js with `session.strategy: 'jwt'`.
- Its JWT callback stores the linked database ID in `token.userId`.
- Its session callback and `lib/auth/auth.edge.ts` map numeric `token.userId` to
  `session.user.dbId`.
- `proxy.ts` rejects sessions without `session.user.dbId`.
- The default HTTP development cookie is `authjs.session-token`; Auth.js uses
  the cookie name as the JWT encryption salt.

Mint a payload with a numeric `userId`. Include `name`, `email`, `picture`, and
`sub` so the local session resembles a normal Auth.js session. Do not include
roles in the token: route checks query roles by database user ID.

## Role selection

Current role sets in `lib/const/api.constants.ts` are:

- Manager routes: `ADMIN` or `MANAGER`
- Administrator routes: `ADMIN`
- Academic routes: `ADMIN` or `PROFESSOR`
- Student routes: `ADMIN` or `STUDENT`

Read the target layout and API route as the authoritative check.

`prisma/scripts/seed-data.ts` currently gives the two developer fixtures
`ADMIN`, `PROFESSOR`, and `STUDENT` unless
`SEED_DEVELOPERS_AS_BARE_STUDENTS=true`. One current fixture is
`aparkerdf@outlook.com`. Query its ID from the disposable database rather than
assuming a numeric ID.

## Disposable database outline

Use a distinct Compose project or a dedicated worktree. Before starting, run
`docker compose ps` and identify any pre-existing database that must remain
untouched.

For a newly created fixture:

1. Supply local-only `DATABASE_USER`, `DATABASE_PASSWORD`, `DATABASE_NAME`, and
   `DATABASE_PORT` values to `docker compose up -d mysql`.
2. Wait for `mysqladmin ping` to succeed.
3. Run `npx prisma migrate deploy` with `DATABASE_URL` and the individual
   database variables.
4. Run `npm run db:seed` with the same variables and keep
   `SEED_DEVELOPERS_AS_BARE_STUDENTS` unset or `false` for manager checks.
5. Query `User.id` by the selected fixture email and verify the corresponding
   `Role` rows before minting the token.

Never use `npm run init` merely for this workflow because it can reset local
data. Never remove an existing volume. If this workflow created the Compose
project and volume, use `docker compose down --volumes` with the same project
scope during cleanup.

## Development server variables

Pass these categories to `npm run dev` without writing real credentials:

- A temporary random `AUTH_SECRET` of at least 32 characters
- `AUTH_URL=http://localhost:3000`
- `AUTH_TRUST_HOST=true`
- Harmless local values for `AZURE_AD_CLIENT_ID` and
  `AZURE_AD_CLIENT_SECRET`
- A syntactically valid dummy issuer such as
  `https://login.microsoftonline.com/common/v2.0`
- The disposable database variables
- Local Azurite defaults only if the tested route needs blob storage

The token helper and the running server must receive the identical
`AUTH_SECRET`. Do not follow the sign-in link; this workflow does not validate
Microsoft Entra login.

## Verification and cleanup

Verify all of the following:

- The protected URL returns the intended page instead of redirecting.
- Protected API requests return successful responses.
- The rendered user matches the selected fixture.
- The server logs show the expected page/API requests without auth failures.
- Browser console and runtime diagnostics contain no authentication errors.
- The browser session is closed afterward.
- The dev server and only newly created local services are stopped.
- Any temporary `.env` created by the workflow is removed.
- `git status --short` shows no workflow-generated repository changes.
