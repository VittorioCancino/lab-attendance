---
name: defensasfic-local-login
description: Create a safe local Auth.js JWT browser session for DefensasFIC when Microsoft Entra credentials or interactive login are unavailable. Use for runtime verification of protected local `/gestor`, `/admin`, `/academico`, or `/student` pages, local role testing, seeded-user browser checks, or requests to access the local app without completing OAuth. Only target loopback development URLs and disposable local data; never use this workflow against staging or production.
---

# DefensasFIC Local Login

Open protected DefensasFIC routes by minting the same encrypted JWT session
cookie that the local Auth.js server accepts. Exercise application RBAC normally;
do not add an authentication bypass to the product.

## Enforce the safety boundary

- Target only `localhost`, `127.0.0.1`, `[::1]`, or a `*.localhost` hostname.
- Use a temporary local `AUTH_SECRET`; never retrieve or reuse a deployed secret.
- Use a disposable database or an existing non-destructive local fixture.
- Never point this workflow at staging, production, shared data, or an externally
  reachable host.
- Never edit authentication, proxy, middleware, or RBAC code to make the login
  work.
- Stop if the application does not use JWT sessions or if the token-to-session
  mapping cannot be established from source.

## Follow the workflow

### 1. Inspect the current authentication contract

Read `lib/auth/auth.ts`, `lib/auth/auth.edge.ts`, `proxy.ts`, the target route's
layout, and the relevant role constants. Confirm all of the following before
minting a cookie:

- Auth.js uses `session.strategy: 'jwt'`.
- The JWT callback and session callback expose the database user identifier.
- The target route authorizes the selected local user's role.
- The cookie name and salt match. For Auth.js defaults, use
  `authjs.session-token` over HTTP and `__Secure-authjs.session-token` over
  HTTPS.

Read [references/defensasfic.md](references/defensasfic.md) for the repository's
current mappings and fixture details, but verify them against source every time.

### 2. Prepare a local authorized user

Inspect existing services before starting anything. Prefer a worktree-scoped or
otherwise isolated Compose project. Apply migrations and seed only the
disposable database, then query the chosen user's numeric database ID. Select a
role that genuinely satisfies the target route; do not place roles inside the
JWT because DefensasFIC resolves roles from the database.

Do not reset, truncate, or replace an existing local database unless the user
explicitly authorized that destructive action.

### 3. Start the app with a temporary secret

Generate a high-entropy local secret and pass the same exact value to both
`next dev` and the token helper. Supply local database settings and harmless
dummy Entra provider values only as needed for configuration parsing. Do not
navigate through the Entra sign-in flow.

Prefer process-scoped environment variables over creating `.env`. If a
temporary ignored env file is necessary, record whether it already existed and
remove only the file created by this workflow.

### 4. Mint the encrypted session token

Run the bundled helper from the DefensasFIC repository root so it can resolve
the repository's installed `next-auth` package:

```sh
local_auth_cookie='authjs.session-token'
local_auth_payload="$(jq -cn \
  --argjson userId "$local_user_id" \
  --arg name "$local_user_name" \
  --arg email "$local_user_email" \
  '{userId: $userId, name: $name, email: $email, picture: null, sub: ($userId | tostring)}')"

local_auth_token="$(
  AUTHJS_BASE_URL='http://localhost:3000' \
  AUTHJS_SECRET="$local_auth_secret" \
  AUTHJS_COOKIE_NAME="$local_auth_cookie" \
  AUTHJS_TOKEN_JSON="$local_auth_payload" \
  node '.agents/skills/defensasfic-local-login/scripts/create-session-token.mjs'
)"
```

Keep the token in memory. Do not print it, write it into the repository, add it
to logs, or persist it as a reusable browser profile.

### 5. Inject the cookie into an isolated browser

When using `agent-browser`, load its skill first and use one isolated,
worktree-scoped session for every command. Open a blank browser, set the cookie
for the local origin, then navigate to the protected route:

```sh
agent-browser --session "$local_browser_session" open
agent-browser --session "$local_browser_session" cookies set \
  "$local_auth_cookie" "$local_auth_token" \
  --url 'http://localhost:3000' \
  --path / \
  --httpOnly \
  --sameSite Lax
agent-browser --session "$local_browser_session" open \
  'http://localhost:3000/gestor/defenses'
```

Add `--secure` only when the local origin uses HTTPS and use the secure cookie
name as the helper salt.

### 6. Verify real authorization and runtime behavior

Confirm the browser remains on the requested route, the protected page and API
requests succeed, the expected user and role are visible, and browser/server
diagnostics contain no authentication errors. Treat this as application and
RBAC verification, not as coverage of the Microsoft Entra OAuth flow.

### 7. Clean up

Close the isolated browser, stop the dev server, unset in-memory credentials,
and stop only the containers created for this check. Remove disposable volumes
only when this workflow created them. Remove temporary ignored env files and
confirm the repository worktree is unchanged.

## Diagnose failures

- Redirect to `/auth/signin`: check the server secret, cookie name, salt,
  origin, and cookie path.
- Redirect to `/auth/unauthorized`: check that `userId` is numeric and maps to
  an existing database user.
- `403` response: verify the database role satisfies the target route.
- Cookie ignored on HTTP: do not use the secure cookie name or `--secure`.
- Provider configuration error: provide harmless local placeholders, but do
  not initiate OAuth.

## Use the bundled resources

- `scripts/create-session-token.mjs`: mint and self-verify a local-only Auth.js
  JWT using the target repository's installed package.
- `references/defensasfic.md`: inspect current DefensasFIC token fields, role
  rules, seed behavior, environment variables, and cleanup checks.
