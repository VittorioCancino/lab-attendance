# API Implementations

## Repository Pattern

For this repository, prefer this split for application mutations and reusable data access:

- `app/api/**/route.ts` for HTTP concerns: auth, query/body parsing, status codes, and response shaping
- `lib/db/*.ts` for database access and domain mapping
- `lib/api/*.ts` for shared client calls that return `Promise<ApiResult<T>>`
- `lib/api/query.ts` for adapters between `ApiResult<T>` and TanStack Query errors/data
- `lib/queries/*.ts` for reusable TanStack Query keys, `queryOptions`, and `useQuery` hooks
- `lib/mutations/*.ts` for reusable `useMutation` hooks and query invalidation rules
- `lib/query-client.ts` for the shared `QueryClient` factory used by `app/providers.tsx`
- `lib/util/*.query.ts` for typed list query helpers built with `createListQueryParams`

Use `Result` values for expected application outcomes. Keep route handler return types explicit.

## Client API State With TanStack Query

This repository has a business requirement to fetch application data through API routes. For client-rendered server state, use TanStack Query instead of hand-written `useEffect + AbortController` fetch code.

Preserve these boundaries:

- Keep `lib/api/*` framework-agnostic. API functions call `apiFetch(...)` + `handleErrorResponse(...)`, return `Promise<ApiResult<T>>`, and accept `signal` through params/options for read requests.
- Put shared read behavior in `lib/queries/*`. Export query key factories plus `queryOptions(...)` helpers or small `useXQuery(...)` hooks.
- Put shared write behavior in `lib/mutations/*`. Mutation hooks call `writeApiResult(...)` and invalidate related query keys on success.
- Put component-specific success/error UI behavior in the component using `mutate(...)` options or `mutateAsync(...)` with local `try/catch`.
- Use `readApiResult(signal, apiCall(...))` in query functions so TanStack's supplied `AbortSignal` controls cancellation.
- Do not instantiate `AbortController` in components for API GET reads. TanStack Query supplies the signal and reverts/cancels stale queries when that signal is consumed by `fetch`.

### Query Example

```ts
// lib/queries/campuses.ts
'use client';

import { queryOptions, useQuery } from '@tanstack/react-query';
import { getCampuses } from '@/lib/api/campuses';
import { readApiResult } from '@/lib/api/query';

export const campusQueryKeys = {
  all: ['campuses'] as const,
  list: () => [...campusQueryKeys.all, 'list'] as const,
};

export function campusesQueryOptions() {
  return queryOptions({
    queryKey: campusQueryKeys.list(),
    queryFn: ({ signal }) => readApiResult(signal, getCampuses({ signal })),
    staleTime: 5 * 60 * 1000,
  });
}

export function useCampusesQuery() {
  return useQuery(campusesQueryOptions());
}
```

### Mutation Example

```ts
// lib/mutations/users.ts
'use client';

import { useMutation, useQueryClient } from '@tanstack/react-query';
import { deleteUser } from '@/lib/api/users';
import { writeApiResult } from '@/lib/api/query';
import { userQueryKeys } from '@/lib/queries/users';

export function useDeleteUserMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (userId: number) => writeApiResult(deleteUser(userId)),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: userQueryKeys.all }),
  });
}
```

### Component Usage

```tsx
const deleteUserMutation = useDeleteUserMutation();

async function onDelete(userId: number) {
  try {
    await deleteUserMutation.mutateAsync(userId);
    setFeedback({ type: 'success', message: 'Usuario eliminado.' });
  } catch (error) {
    setFeedback({
      type: 'error',
      message: getApiErrorMessage(error, 'No se pudo eliminar el usuario.'),
    });
  }
}
```

## Auth And Role Checks

This repository now uses the database as the source of truth for authorization.

- Treat JWT/session data as identity-only for authorization-sensitive flows; use `session.user.dbId` or `request.auth.user.dbId` to resolve the current user
- In `app/api/**/route.ts`, import `requireRole` from `@/lib/auth/role-check`, not from `@/lib/util/api`
- `requireRole(...)` is async and must be awaited: `const roleRes = await requireRole(request, MANAGER_ROLES, logger)`
- For privileged pages and layouts, use `hasRequiredRole(...)` or `getUserRoles(...)` from `@/lib/auth/role-check` instead of reading `session.roles`
- Keep `proxy.ts` focused on authentication-only redirects unless the user explicitly changes the repo-wide pattern

## Route-local Scopes And Errors

When a route can be called by more than one role, ownership model, or request
shape, put the scope resolution in a `scopes.ts` file next to `route.ts`. This
keeps the handler focused on HTTP flow: parse input, resolve scope, perform the
business operation, map the result, and log important outcomes.

Use route-local scope helpers for patterns such as:

- A student can act on their own record while a manager can act on a target student
- JSON and multipart upload requests need different payload parsing
- The route needs a role-specific target id or permission before validating files

Keep the helpers specific to the route unless they are reusable across multiple
route directories. Names like `resolveStudentJsonScope`,
`resolveStudentUploadScope`, and `resolveStudentUploadScopeRole` are preferable
to spreading conditional role checks throughout `route.ts`.

For route-specific API errors, put `customError(...)` constants and
validation-error mappers in an `errors.ts` file next to `route.ts`. Import those
constants into the handler instead of declaring custom error payloads inline,
especially when the route has multiple custom errors or maps file-validation
results to localized `ApiError` responses.

```txt
app/api/v1/students/birth-certificate/
  route.ts
  scopes.ts
  errors.ts
  storage-cleanup.ts
```

```ts
// app/api/v1/students/birth-certificate/errors.ts
import { BIRTH_CERTIFICATE_MAX_SIZE_MB } from '@/lib/const/blob.constants';
import type { ApiError } from '@/lib/types/api.types';
import { customError } from '@/lib/util/api';
import { GenericPdfFileValidationError } from '@util/pdf';

export const STUDENT_NOT_FOUND_ERROR = customError(
  'El estudiante no fue encontrado.',
  { studentId: ['El estudiante no fue encontrado.'] },
);

export const BIRTH_CERTIFICATE_REQUIRED_ERROR = customError(
  'El certificado de nacimiento es requerido.',
  { birthCertificate: ['El certificado de nacimiento es requerido.'] },
);

export const BIRTH_CERTIFICATE_NOT_FOUND_ERROR = customError(
  'El certificado de nacimiento no fue encontrado.',
  {
    birthCertificate: ['El certificado de nacimiento no fue encontrado.'],
  },
);

const BIRTH_CERTIFICATE_INVALID_FILE_ERROR = customError(
  'El certificado de nacimiento debe adjuntarse en formato PDF.',
  {
    birthCertificate: [
      'El certificado de nacimiento debe adjuntarse en formato PDF.',
    ],
  },
);

const BIRTH_CERTIFICATE_EMPTY_FILE_ERROR = customError(
  'El certificado de nacimiento no puede estar vacio.',
  { birthCertificate: ['El certificado de nacimiento no puede estar vacio.'] },
);

const BIRTH_CERTIFICATE_TOO_LARGE_ERROR = customError(
  `El certificado de nacimiento supera el tamano maximo permitido (${BIRTH_CERTIFICATE_MAX_SIZE_MB}MB).`,
  {
    birthCertificate: [
      `El certificado de nacimiento supera el tamano maximo permitido (${BIRTH_CERTIFICATE_MAX_SIZE_MB}MB).`,
    ],
  },
);

export function birthCertificatePdfValidationError(
  error: GenericPdfFileValidationError,
): ApiError {
  switch (error) {
    case GenericPdfFileValidationError.EmptyFile:
      return BIRTH_CERTIFICATE_EMPTY_FILE_ERROR;
    case GenericPdfFileValidationError.ExceedsMaxSize:
      return BIRTH_CERTIFICATE_TOO_LARGE_ERROR;
    case GenericPdfFileValidationError.InvalidPdf:
      return BIRTH_CERTIFICATE_INVALID_FILE_ERROR;
  }
}
```

## Query Helper

```ts
// lib/util/block.query.ts
import { createListQueryParams } from '@/lib/util/list-query-params';

export const blockListQuery = createListQueryParams({
  pagination: {
    defaultPage: 1,
    defaultPageSize: 10,
    maxPageSize: 50,
    allowedPageSizes: [10, 20, 50],
  },
  sorting: {
    fields: ['startTime'] as const,
    orders: ['asc', 'desc'] as const,
    defaultField: 'startTime',
    defaultOrderByField: {
      startTime: 'asc',
    },
  },
  options: {
    termId: {
      type: 'number',
      required: false,
      paramName: 'termId',
    },
  },
});

export type BlockListSortField = (typeof blockListQuery.fields)[number];
export type BlockListSortOrder = (typeof blockListQuery.orders)[number];
```

Use the helper in both places:

- In route handlers: `const queryParams = blockListQuery.read(searchParams)`
- In shared API clients: `blockListQuery.toSearchParams(...)`

## DB Wrapper Functions

Keep database access in `lib/db/*.ts` and return typed `Result` values so route handlers can translate them into HTTP responses.

```ts
// lib/db/blocks.ts
import 'server-only';

import type { Result } from 'ts-results';
import { prisma } from '@/lib/prisma';
import type { BlockSummary, CreateBlockRequest } from '@/lib/types/block.types';
import { type DbError, safeDbCall } from '@util/db';

const BLOCK_SELECT = {
  id: true,
  name: true,
  startTime: true,
  endTime: true,
  _count: { select: { defenses: true } },
} as const;

function toTimeString(value: Date): string {
  const hours = value.getUTCHours();
  const minutes = value.getUTCMinutes();
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
}

function mapBlockSummary(block: {
  id: number;
  name: string;
  startTime: Date;
  endTime: Date;
  _count: { defenses: number };
}): BlockSummary {
  return {
    id: block.id,
    name: block.name,
    startTime: toTimeString(block.startTime),
    endTime: toTimeString(block.endTime),
    defenseCount: block._count.defenses,
  };
}

export async function findBlocksByTermId(
  termId: number,
): Promise<Result<BlockSummary[], DbError>> {
  return safeDbCall(async () => {
    const blocks = await prisma.block.findMany({
      where: { termId },
      orderBy: { startTime: 'asc' },
      select: BLOCK_SELECT,
    });

    return blocks.map(mapBlockSummary);
  });
}

export async function createBlock(
  termId: number,
  data: CreateBlockRequest,
): Promise<Result<BlockSummary, DbError>> {
  return safeDbCall(async () => {
    const block = await prisma.block.create({
      data: {
        termId,
        name: data.name,
        startTime: new Date(`1970-01-01T${data.startTime}:00.000Z`),
        endTime: new Date(`1970-01-01T${data.endTime}:00.000Z`),
      },
      select: BLOCK_SELECT,
    });

    return mapBlockSummary(block);
  });
}
```

If the route also needs to verify a related entity before writing, import another DB function instead of querying Prisma directly in the handler.

```ts
// lib/db/terms.ts
import { prisma } from '@/lib/prisma';
import type { Result } from 'ts-results';
import type { TermSummary } from '@/lib/types/term.types';
import { type DbError, safeDbCall } from '@util/db';

function mapTermSummary(term: {
  id: number;
  name: string;
  startDate: Date;
  endDate: Date;
}): TermSummary {
  return {
    id: term.id,
    name: term.name,
    startDate: term.startDate.toISOString().slice(0, 10),
    endDate: term.endDate.toISOString().slice(0, 10),
  };
}

export async function findTermById(
  termId: number,
): Promise<Result<TermSummary | null, DbError>> {
  return safeDbCall(async () => {
    const term = await prisma.term.findUnique({
      where: { id: termId },
      select: {
        id: true,
        name: true,
        startDate: true,
        endDate: true,
      },
    });

    if (term === null) {
      return null;
    }

    return mapTermSummary(term);
  });
}
```

## Route Handler Example

This pattern matches the existing API routes in the repository: auth wrapper,
explicit return type, list query parsing, DB wrapper calls, shared API error
helpers, and route-specific errors imported from `./errors`.

## Route Logging Convention

When adding or updating `app/api/**/route.ts` handlers, use the shared logger utilities instead of ad hoc `console.*` calls.

- Create one request-scoped child logger near the top of the handler with `createRequestLogger(request)`
- Reuse that logger for the full request instead of creating additional base loggers
- Log structured fields such as `createdUserId`, `targetUserId`, `termId`, `defenseId`, or `conflictField` instead of embedding details in the message string
- Minimize PII in logs. Prefer internal IDs and small safe metadata over full emails, full user records, request bodies, tokens, cookies, or authorization headers
- Keep expected client-facing error responses unchanged. Logging should improve server observability, not leak internals to the client
- Reserve `error` logs for unexpected failures and `500` paths

### Recommended Levels

- `info`: important successful business actions and state transitions such as user creation, defense publication, scheduling, or bulk import completion
- `warn`: handled but unusual or denied actions such as authorization failures or suspicious access attempts
- `error`: unexpected exceptions, failed dependencies, or fallback `500` responses
- `debug`: local investigation details only; do not rely on this level for important production audit trails

### Usually Do Not Log

- Routine `400` validation failures from `parseJsonBody(...)` or query parsing helpers
- Common expected conflicts such as `409` duplicate values, unless the event is operationally important enough to justify an `info` log
- Every successful `GET` request by default
- Full request payloads or large imported files

### Example

```ts
import { requireRole } from '@/lib/auth/role-check';
import { createRequestLogger } from '@/lib/log/request-logger';

export const POST = auth(async function POST(request): Promise<
  NextResponse<ApiError> | NextResponse<CreateAdminResponse>
> {
  const logger = createRequestLogger(request);

  const roleRes = await requireRole(request, MANAGER_ROLES, logger);
  if (roleRes.err) {
    return roleRes.val;
  }

  const bodyRes = await parseJsonBody(request, NewAdminSchema);
  if (bodyRes.err) {
    return bodyRes.val;
  }

  const result = await createAdminUser(bodyRes.val);
  if (result.ok) {
    logger.info({ createdUserId: result.val.id }, 'Admin created successfully');
    return NextResponse.json(result.val, { status: 201 });
  }

  logger.error(
    { err: result.val.error, isPrisma: result.val.isPrisma },
    'Unexpected error creating admin',
  );
  return NextResponse.json(internalServerError(), { status: 500 });
});
```

```tsx
// app/api/v1/blocks/route.ts
import { auth } from '@/lib/auth/auth';
import { requireRole } from '@/lib/auth/role-check';
import { MANAGER_ROLES } from '@/lib/const/api.constants';
import { createBlock, findBlocksByTermId } from '@/lib/db/blocks';
import { findTermById } from '@/lib/db/terms';
import { createRequestLogger } from '@/lib/log/request-logger';
import type { ApiError } from '@/lib/types/api.types';
import type {
  CreateBlockResponse,
  GetBlocksResponse,
} from '@/lib/types/block.types';
import { blockListQuery } from '@/lib/util/block.query';
import { internalServerError, parseJsonBody } from '@/lib/util/api';
import { uniqueViolationField } from '@util/db';
import {
  DUPLICATE_BLOCK_NAME_ERROR,
  INVALID_TERM_ID_QUERY_ERROR,
  TERM_NOT_FOUND_ERROR,
} from './errors';
import { NextResponse } from 'next/server';
import * as z from 'zod';

const TIME_REGEX = /^([01]\d|2[0-3]):[0-5]\d$/;

const CreateBlockBodySchema = z
  .object({
    name: z.string().trim().min(1).max(80),
    startTime: z.string().regex(TIME_REGEX),
    endTime: z.string().regex(TIME_REGEX),
  })
  .superRefine((value, ctx) => {
    if (value.startTime >= value.endTime) {
      ctx.addIssue({
        code: 'custom',
        path: ['endTime'],
        message: 'La hora de inicio debe ser anterior a la hora de fin.',
      });
    }
  });

export const GET = auth(async function GET(request): Promise<
  NextResponse<ApiError> | NextResponse<GetBlocksResponse>
> {
  const logger = createRequestLogger(request);

  const roleRes = await requireRole(request, MANAGER_ROLES, logger);
  if (roleRes.err) {
    return roleRes.val;
  }

  const searchParams = new URL(request.url).searchParams;
  const queryParams = blockListQuery.read(searchParams);

  if (queryParams.options.termId === undefined) {
    return NextResponse.json(INVALID_TERM_ID_QUERY_ERROR, { status: 400 });
  }

  const termRes = await findTermById(queryParams.options.termId);
  if (termRes.err) {
    logger.error(
      {
        termId: queryParams.options.termId,
        err: termRes.val.error,
        isPrisma: termRes.val.isPrisma,
      },
      'Failed to validate term before listing blocks',
    );
    return NextResponse.json(internalServerError(), { status: 500 });
  }
  if (termRes.val === null) {
    return NextResponse.json(TERM_NOT_FOUND_ERROR, { status: 404 });
  }

  const blocksRes = await findBlocksByTermId(queryParams.options.termId);
  if (blocksRes.err) {
    logger.error(
      {
        termId: queryParams.options.termId,
        err: blocksRes.val.error,
        isPrisma: blocksRes.val.isPrisma,
      },
      'Failed to list blocks',
    );
    return NextResponse.json(internalServerError(), { status: 500 });
  }

  return NextResponse.json<GetBlocksResponse>({
    blocks: blocksRes.val,
  });
});

export const POST = auth(async function POST(request): Promise<
  NextResponse<ApiError> | NextResponse<CreateBlockResponse>
> {
  const logger = createRequestLogger(request);

  const roleRes = await requireRole(request, MANAGER_ROLES, logger);
  if (roleRes.err) {
    return roleRes.val;
  }

  const searchParams = new URL(request.url).searchParams;
  const queryParams = blockListQuery.read(searchParams);

  if (queryParams.options.termId === undefined) {
    return NextResponse.json(INVALID_TERM_ID_QUERY_ERROR, { status: 400 });
  }

  const bodyRes = await parseJsonBody(request, CreateBlockBodySchema);
  if (bodyRes.err) {
    return bodyRes.val;
  }

  const termRes = await findTermById(queryParams.options.termId);
  if (termRes.err) {
    logger.error(
      {
        termId: queryParams.options.termId,
        err: termRes.val.error,
        isPrisma: termRes.val.isPrisma,
      },
      'Failed to validate term before creating block',
    );
    return NextResponse.json(internalServerError(), { status: 500 });
  }
  if (termRes.val === null) {
    return NextResponse.json(TERM_NOT_FOUND_ERROR, { status: 404 });
  }

  const blockRes = await createBlock(queryParams.options.termId, bodyRes.val);

  if (blockRes.err) {
    if (uniqueViolationField(blockRes.val)) {
      return NextResponse.json(DUPLICATE_BLOCK_NAME_ERROR, { status: 409 });
    }

    logger.error(
      {
        termId: queryParams.options.termId,
        err: blockRes.val.error,
        isPrisma: blockRes.val.isPrisma,
      },
      'Failed to create block',
    );

    return NextResponse.json(internalServerError(), { status: 500 });
  }

  logger.info({ termId: queryParams.options.termId }, 'Created block');

  return NextResponse.json<CreateBlockResponse>(
    { block: blockRes.val },
    { status: 201 },
  );
});
```

## Shared API Client Example

Mirror the route query helper in `lib/api/*` so the browser-facing call path stays consistent with the route handler.

```ts
// lib/api/blocks.ts
import {
  apiFetch,
  handleErrorResponse,
  type ApiResult,
} from '@/lib/api/client';
import { blockListQuery } from '@/lib/util/block.query';
import type {
  CreateBlockRequest,
  CreateBlockResponse,
  GetBlocksResponse,
} from '@/lib/types/block.types';

export async function getBlocks(
  termId: number,
  signal?: AbortSignal,
): Promise<ApiResult<GetBlocksResponse>> {
  const searchParams = blockListQuery.toSearchParams({
    options: { termId },
  });

  return handleErrorResponse<GetBlocksResponse>(
    apiFetch(`/api/v1/blocks?${searchParams.toString()}`, {
      method: 'GET',
      credentials: 'include',
      signal,
    }),
    { returnBody: true },
  );
}

export async function createBlock(
  termId: number,
  data: CreateBlockRequest,
): Promise<ApiResult<CreateBlockResponse>> {
  const searchParams = blockListQuery.toSearchParams({
    options: { termId },
  });

  return handleErrorResponse<CreateBlockResponse>(
    apiFetch(`/api/v1/blocks?${searchParams.toString()}`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }),
    { returnBody: true },
  );
}
```

## Implementation Notes

- Read query params with the dedicated helper instance, not with manual parsing
- Keep Prisma access out of `route.ts` when it belongs in a reusable `lib/db/*` function
- Import `requireRole` from `@/lib/auth/role-check` and remember it is async
- Map `Result` errors from DB helpers into HTTP responses in the route handler
- Use `parseJsonBody` and shared API error builders instead of ad hoc parsing and error objects
- Keep the client layer on `lib/api/*` and return `ApiResult<T>` via `handleErrorResponse(...)`
