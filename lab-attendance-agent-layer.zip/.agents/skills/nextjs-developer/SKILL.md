---
name: nextjs-developer
description: 'Use when building Next.js 14+/16 applications with App Router, server components, server actions, route handlers, or client API-state flows. Invoke to configure API routes, middleware, TanStack Query client data fetching, mutations and invalidation, streaming SSR, generateMetadata for SEO, loading/error boundaries, or deployment. Triggers on: Next.js, App Router, RSC, Server Components, Server Actions, Route Handlers, TanStack Query, React Query, generateMetadata, loading.tsx, Next.js performance.'
license: MIT
metadata:
  author: https://github.com/Jeffallan
  version: '1.2.3'
  domain: frontend
  triggers: Next.js, Next.js 14, Next.js 16, App Router, Server Components, Server Actions, React Server Components, Route Handlers, TanStack Query, React Query, Next.js performance
  role: specialist
  scope: implementation
  output-format: code
  related-skills: typescript-pro
---

# Next.js Developer

Senior Next.js developer with expertise in Next.js 14+/16 App Router, server components, route handlers, TanStack Query client server-state, and full-stack deployment with focus on performance and SEO excellence.

## Core Workflow

1. **Architecture planning** — Define app structure, routes, layouts, rendering strategy
2. **Implement routing** — Create App Router structure with layouts, templates, loading/error states
3. **Data layer** — Set up server components, API routes, client API-state queries/mutations, caching, revalidation
4. **Optimize** — Images, fonts, bundles, streaming, edge runtime
5. **Deploy** — Production build, environment setup, monitoring
   - Validate: run `next build` locally, confirm zero type errors, check `NEXT_PUBLIC_*` and server-only env vars are set, run Lighthouse/PageSpeed to confirm Core Web Vitals > 90

## Reference Guide

Load detailed guidance based on context:

| Topic               | Reference                           | Load When                                                                                            |
| ------------------- | ----------------------------------- | ---------------------------------------------------------------------------------------------------- |
| App Router          | `references/app-router.md`          | File-based routing, layouts, templates, route groups                                                 |
| Server Components   | `references/server-components.md`   | RSC patterns, streaming, client boundaries                                                           |
| Data Fetching       | `references/data-fetching.md`       | fetch, caching, ISR, on-demand revalidation                                                          |
| API Implementations | `references/api-implementations.md` | route handlers, `lib/db/*`, `lib/api/*`, TanStack Query, mutations, query params, typed API patterns |

## Constraints

### MUST DO (Next.js-specific)

- Use App Router (`app/` directory), never Pages Router (`pages/`)
- Keep components as Server Components by default; add `'use client'` only at the leaf boundary where interactivity is required
- Use native `fetch` with explicit `cache` / `next.revalidate` options for server/external fetches — do not rely on implicit caching
- In this repository, preserve the API-route boundary for business-required client data access: pure API calls live in `lib/api/*`, reusable reads live in `lib/queries/*`, reusable writes live in `lib/mutations/*`, and TanStack Query owns client request lifecycle/cancellation
- Use `generateMetadata` (or the static `metadata` export) for all SEO — never hardcode `<title>` or `<meta>` tags in JSX
- Optimize every image with `next/image`; never use a plain `<img>` tag for content images
- Add `loading.tsx` and `error.tsx` at every route segment that performs async data fetching
- For `app/api/**/route.ts`, use the shared logger utilities, create a request-scoped child logger, log important outcomes with structured fields, minimize PII, and keep client-facing error responses generic
- For route handlers that serve multiple authorization scopes, put scope resolution helpers in a route-local `scopes.ts` file next to `route.ts` and keep `route.ts` focused on HTTP flow
- For route-specific API errors, put `customError(...)` constants and validation-error mappers in a route-local `errors.ts` file next to `route.ts`, then import them into the handler
- In this repository, treat JWT/session data as identity-only for authorization-sensitive work: route handlers should `await requireRole(...)` from `@/lib/auth/role-check`, while server pages and layouts should load current roles with `hasRequiredRole(...)` or `getUserRoles(...)`

### MUST NOT DO

- Convert components to Client Components just to access data unless the repository/business requirement explicitly says data must be fetched through API routes from client flows
- Put `useQuery` or `useMutation` inside `lib/api/*`; keep `lib/api/*` as framework-agnostic `ApiResult<T>` transport functions
- Hand-write `useEffect + AbortController` for API GET state that TanStack Query can model with a query key and supplied `signal`
- Skip `loading.tsx`/`error.tsx` boundaries on async route segments
- Deploy without running `next build` to confirm zero errors

## Code Examples

### Server Component with data fetching and caching

```tsx
// app/products/page.tsx
import { Suspense } from 'react';

async function ProductList() {
  // Revalidate every 60 seconds (ISR)
  const res = await fetch('https://api.example.com/products', {
    next: { revalidate: 60 },
  });
  if (!res.ok) throw new Error('Failed to fetch products');
  const products: Product[] = await res.json();

  return (
    <ul>
      {products.map((p) => (
        <li key={p.id}>{p.name}</li>
      ))}
    </ul>
  );
}

export default function Page() {
  return (
    <Suspense fallback={<p>Loading…</p>}>
      <ProductList />
    </Suspense>
  );
}
```

### Server Action with form handling and revalidation

```tsx
// app/products/actions.ts
'use server';

import { revalidatePath } from 'next/cache';

export async function createProduct(formData: FormData) {
  const name = formData.get('name') as string;
  await db.product.create({ data: { name } });
  revalidatePath('/products');
}

// app/products/new/page.tsx
import { createProduct } from '../actions';

export default function NewProductPage() {
  return (
    <form action={createProduct}>
      <input name="name" placeholder="Product name" required />
      <button type="submit">Create</button>
    </form>
  );
}
```

### generateMetadata for dynamic SEO

```tsx
// app/products/[id]/page.tsx
import type { Metadata } from 'next';

export async function generateMetadata({
  params,
}: {
  params: { id: string };
}): Promise<Metadata> {
  const product = await fetchProduct(params.id);
  return {
    title: product.name,
    description: product.description,
    openGraph: { title: product.name, images: [product.imageUrl] },
  };
}
```

## Output Templates

When implementing Next.js features, provide:

1. App structure (route organization)
2. Layout/page components with proper data fetching
3. API routes and client side if mutation is needed on some data in the database.
4. Configuration (`next.config.js`, TypeScript)

## Knowledge Reference

Next.js 14+, App Router, React Server Components, Server Actions, Streaming SSR, Partial Prerendering, next/image, next/font, Metadata API, Route Handlers, Middleware, Edge Runtime, Turbopack.
