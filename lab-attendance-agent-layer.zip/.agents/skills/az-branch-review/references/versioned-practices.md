# Versioned practices reference

Use this reference when reviewing DefensasFIC branches that touch framework or
library behavior. It captures the current version evidence used when this skill
was created and separates repo-required practices from optional library ideas.

## Verified stack versions

Resolved from `package-lock.json` on 2026-05-29:

| Package                         | Resolved version | Practice source status                                                                                                          |
| ------------------------------- | ---------------: | ------------------------------------------------------------------------------------------------------------------------------- |
| `next`                          |         `16.2.6` | Next docs fetched as Latest Version `16.2.6`, last updated 2026-05-28.                                                          |
| `react` / `react-dom`           |         `19.2.3` | React docs current for React 19 escape-hatch guidance.                                                                          |
| `@tanstack/react-query`         |        `5.100.5` | TanStack Query docs `latest` for React v5.                                                                                      |
| `@tanstack/eslint-plugin-query` |        `5.100.5` | TanStack Query v5 ESLint rules are configured in `eslint.config.ts`.                                                            |
| `prisma` / `@prisma/client`     |          `7.8.0` | Prisma ORM latest transaction guidance is applicable; verify API details if using brand-new features.                           |
| `zod`                           |          `4.3.6` | Zod 4 docs apply.                                                                                                               |
| `next-auth`                     |  `5.0.0-beta.31` | Auth.js / NextAuth v5 beta docs apply; verify beta API surface in repo.                                                         |
| `tailwindcss`                   |          `4.2.2` | Tailwind docs fetched were v4.3; use only broad v4 guidance already reflected in repo config unless verifying 4.2 specifically. |
| `typescript`                    |          `5.9.3` | Strict type-aware ESLint rules are configured.                                                                                  |

When reviewing a future branch, re-check `package-lock.json` or `npm ls` if the
branch changes dependencies. Do not apply advice from docs or articles written
for older App Router, Pages Router, React Query v3/v4, Zod 3, NextAuth v4, or
Tailwind 3 unless the branch is intentionally migrating compatibility code.

## Next.js 16.2 App Router practices

Sources checked:

- `https://nextjs.org/docs/app/getting-started/server-and-client-components`
- `https://nextjs.org/docs/app/getting-started/fetching-data`
- `https://nextjs.org/docs/app/api-reference/file-conventions/route`
- `https://nextjs.org/docs/app/api-reference/file-conventions/proxy`
- `https://nextjs.org/docs/app/api-reference/config/next-config-js/cacheComponents`
- `https://nextjs.org/docs/app/api-reference/directives/use-cache`
- `https://nextjs.org/docs/app/api-reference/functions/unstable_cache`
- `https://nextjs.org/docs/app/guides/environment-variables`

Review implications for this repo:

- Pages and layouts are Server Components by default. A branch should add
  `'use client'` only at the smallest boundary that needs state, event handlers,
  browser APIs, lifecycle logic, or client-only hooks.
- Marking a file with `'use client'` pulls its imported module graph and directly
  rendered components into the client bundle. Treat broad client boundaries as a
  performance and leakage risk.
- Props passed from Server Components to Client Components must be React
  serializable. Do not pass Prisma models containing non-serializable values,
  class instances, server functions except intentional Server Actions, or secrets.
- Route Handler dynamic `params` are promises in Next 15+ / 16:
  `params: Promise<{ id: string }>` or `RouteContext<'/path/[id]'>`. Validate
  params with Zod before use.
- Route Handlers use Web `Request`/`Response` APIs. This repo still standardizes
  on `NextResponse<ApiError | T>`, shared API error builders, and Auth.js
  `auth(...)` wrappers.
- `GET` Route Handlers are dynamic by default since Next 15. Do not assume static
  caching for API responses.
- Next 16 renamed `middleware.ts` to `proxy.ts`. Proxy is a network boundary and
  should be used sparingly with explicit matchers. Do not rely on Proxy as the
  only authorization layer; verify authorization near the data access or mutation.
- This repo's `next.config.ts` does **not** currently enable `cacheComponents`.
  Therefore do not require `use cache`, `cacheLife`, `cacheTag`, or Cache
  Components patterns in ordinary reviews. If a branch enables
  `cacheComponents`, review the new constraints carefully: runtime APIs such as
  `cookies()`, `headers()`, `params`, and `searchParams` must be outside cached
  scopes and passed as serializable arguments.
- `unstable_cache` is replaced by `use cache` in Next 16, but `use cache` only
  applies when `cacheComponents: true` is enabled. If a branch introduces new
  cache behavior, verify the config and migration path rather than mechanically
  preferring one API.
- Environment variables without `NEXT_PUBLIC_` are server-only. Public variables
  are inlined at build time, so do not expose runtime secrets or environment-
  specific values through `NEXT_PUBLIC_` unless build-time freezing is intended.

## React 19 UI practices

Source checked:

- `https://react.dev/learn/you-might-not-need-an-effect`

Review implications:

- Effects are for synchronizing with external systems, not for rendering-derived
  state, event-specific logic, or data transformations.
- Compute derived values during render. Use `useMemo` only for measured expensive
  pure calculations, not as a blanket optimization.
- Reset entire subtrees with `key` when the identity changes. Prefer storing IDs
  and deriving selected objects instead of effect-resetting copied state.
- Event-caused mutations belong in event handlers or TanStack mutations, not in
  effects watching a flag.
- Effects used for fetching must address race conditions. In this repo, client
  API-route GET state should generally use TanStack Query instead.
- `useSyncExternalStore` is preferred over hand-written subscription effects for
  external stores.

## TanStack Query v5 practices

Sources checked:

- `https://tanstack.com/query/latest/docs/framework/react/guides/query-functions`
- `https://tanstack.com/query/latest/docs/framework/react/guides/query-cancellation`
- `https://tanstack.com/query/latest/docs/framework/react/guides/invalidations-from-mutations`

Review implications:

- Query functions must return a promise that resolves to data or throws/rejects
  on error. `undefined` is not successful query data; use `null` when the
  resource can be absent.
- TanStack provides `signal` to query functions. Pass it into this repo's
  `lib/api/*` functions and then into `fetch` via `apiFetch`.
- This repo's query functions should unwrap `ApiResult<T>` with
  `readApiResult(signal, apiCall({ signal }))`. That intentionally throws
  `ApiClientError` for TanStack error state.
- Mutations should use `useMutation`, unwrap with `writeApiResult(...)`, and
  invalidate relevant query keys in `onSuccess`. If invalidation must complete
  before pending state clears, `onSuccess` should return/await the invalidation
  promise.
- The repo already enables `@tanstack/eslint-plugin-query` recommended rules.
  Review branches for unstable query clients, unstable dependencies, rest
  destructuring issues, void query functions, and non-reusable query options.

## Prisma 7 / MySQL data consistency practices

Source checked:

- `https://www.prisma.io/docs/orm/prisma-client/queries/transactions`

Review implications:

- Use nested writes for dependent writes that naturally fit a single Prisma
  operation.
- Use `$transaction([...])` for independent operations that must succeed or fail
  atomically.
- Use interactive transactions only for read-modify-write logic that cannot be
  expressed with nested writes or bulk operations, and keep them short. Avoid
  network calls or slow work inside the transaction.
- MySQL's default transaction isolation is `RepeatableRead`. For high-conflict
  concurrent writes where serial order matters, consider Serializable isolation
  plus retry handling for Prisma write-conflict errors.
- For assignment, scheduling, committee membership, state transitions, roster
  imports, evaluation, and acta versioning, review whether transactions,
  uniqueness constraints, idempotency, or optimistic concurrency checks are
  needed.
- Do not run direct Prisma access from Client Components or browser-importable
  modules. Keep server-only modules guarded and layered through `lib/db/*` or
  established server modules.

## Zod 4 practices

Sources checked:

- `https://zod.dev/v4`
- `https://zod.dev/packages/core`

Review implications:

- Zod 4 is the active version in this repo. Do not recommend Zod 3-only APIs.
- Keep route input schemas in `lib/types/*.types.ts` for shared JSON contracts.
  Route-local params/query schemas are acceptable when they are only route
  plumbing and not a public shared contract.
- Prefer `safeParse` at request boundaries and convert failures with shared API
  builders such as `fromZodError`.
- Zod 4 includes `z.file()`, top-level string formats, JSON Schema conversion,
  and `z.prettifyError`. Do not add third-party validation helpers unless the
  branch has a clear repeated need and the package supports Zod 4.

## Auth.js / NextAuth v5 practices

Sources checked:

- `https://authjs.dev/getting-started/migrating-to-v5`
- `https://authjs.dev/getting-started/session-management/protecting`

Review implications:

- This repo uses NextAuth v5 beta with App Router-first `auth`, `handlers`,
  `signIn`, and `signOut` exports.
- NextAuth v5 recommends `auth()` as the universal server-side session API and
  wrapping App Router API handlers with `auth(...)`.
- For Next 16, use `proxy.ts`, not new `middleware.ts`. The repo already splits
  edge-safe auth config from full server auth config; preserve that separation so
  Proxy does not import database-bound Prisma code.
- Auth.js docs explicitly warn not to rely only on Proxy for authorization.
  Branches must verify role and resource permissions at route/data boundaries.
- Session/JWT data should remain identity-only in this repo. Role and resource
  permissions should be loaded/checked through repository auth helpers.

## Tailwind CSS 4 practices

Source checked:

- `https://tailwindcss.com/docs/installation/framework-guides/nextjs` returned
  Tailwind docs v4.3, while this repo resolves `tailwindcss@4.2.2`.

Review implications:

- Treat Tailwind v4.3 docs as broadly relevant to Tailwind 4 setup only. Do not
  require a v4.3-specific utility or config behavior unless verifying it exists
  in 4.2.2.
- This repo already uses Tailwind 4 and `@tailwindcss/postcss`. UI reviews should
  focus on project tokens and existing component style, not dependency churn.
- Prefer Tailwind/CSS for responsive presentation and shared tokens from
  `tailwind.config.ts`. Avoid hardcoded hex colors and JS viewport checks for
  presentational changes.

## Optional library considerations

These are not default recommendations. Mention or approve a new dependency only
when it solves a repeated problem better than the repo's existing helpers and is
compatible with the locked stack.

### `server-only` / `client-only`

- Registry latest: `0.0.1` marker packages.
- Next 16 docs say installing them is optional because Next handles these imports
  internally and provides type declarations. Install only if tooling starts
  flagging extraneous dependencies or package management requires explicit
  entries.
- This repo already imports `server-only` in many server modules without listing
  it directly. Do not ask a branch to add the package just because it added a
  correct `import 'server-only'` marker.

### `zod-form-data`

- Registry latest checked: `3.0.1`; peer dependency is `zod >= 3.25.0`, so it
  can work with Zod 4.
- Next route docs mention it as useful for `FormData`, but this repo already has
  `parseFormData`, `parseFormFile`, `parseJsonFromString`, and Zod 4 `z.file()`
  patterns in `@/lib/util/api`.
- Consider only for complex repeated form parsing/coercion where existing shared
  utilities become unwieldy. A one-off route with a few fields should use the
  existing utilities.

### `@t3-oss/env-nextjs`

- Registry latest checked: `0.13.11`; peers include TypeScript `>=5.0.0` and
  `zod ^3.24.0 || ^4.0.0`, compatible with this repo.
- Relevant if the repo wants centralized runtime/build-time environment schema
  validation. It is not required for ordinary route or UI changes.
- If introduced, review Azure App Service/Oryx behavior carefully: required env
  validation must not make `npm install --production`, `npm run build`, or
  `npm run start` fail in environments where values are intentionally injected
  later unless that deployment behavior is deliberate and documented.

### `nuqs`

- Registry latest checked: `2.8.9`; peers include Next `>=14.2.0` and React
  `>=18.2.0 || ^19.0.0-0`, compatible with this repo.
- Relevant for complex URL search-params state in Client Components. This repo
  already has route/query helper patterns such as `lib/util/*.query.ts` and
  TanStack query keys, so do not add it for simple pagination/search unless it
  clearly reduces duplicated URL-state logic across multiple screens.

### Server Action helper libraries

- This repo currently standardizes most client-visible database writes through
  API routes, `lib/api/*`, and TanStack mutations. Do not recommend adding a
  Server Action abstraction library just because Next 16 supports Server
  Functions.
- If a branch intentionally introduces Server Actions, review authorization,
  validation, cache invalidation, progressive enhancement, and whether this is a
  deliberate architectural shift from the existing API-route boundary.
