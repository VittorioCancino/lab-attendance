---
name: az-branch-review
description: >-
  Review DefensasFIC branches and pull-request candidates against develop with
  strict attention to business logic, Next.js App Router architecture,
  repository conventions, TypeScript error handling, Prisma/data consistency,
  RBAC, API contracts, and merge risk. Make sure to use this skill whenever the
  user asks to review a branch, review a PR candidate, compare current work to
  develop, decide whether a branch is safe to merge, or produce an
  approve/request-changes recommendation for this repository.
---

# DefensasFIC Branch Review

Review the current branch as a candidate to merge into `develop`, unless the
user explicitly names another target branch. The goal is not to summarize every
changed file; it is to find behavior, architecture, data, and maintainability
risks introduced by the branch.

This repository is a Next.js 16 / React 19 / TypeScript application for the
Facultad de Ingenieria y Ciencias defense workflow. Code review should combine
normal engineering judgment with the project rules in `AGENTS.md`, the product
rules in the domain model, and the actual patterns already present in the
codebase.

## Version awareness and references

When a branch touches framework behavior, client/server boundaries, data
fetching, Prisma, validation, auth, Tailwind, dependencies, or build/deployment
configuration, read `references/versioned-practices.md`. It records the verified
package versions and the official docs checked for this repo.

Before applying a best-practice claim from external docs, blog posts, or memory,
verify that it matches the branch's resolved package versions. Prefer official
docs for the exact major version. If the docs are newer than this repo's package
version, use only guidance that is clearly stable for the installed version or
state the uncertainty instead of treating it as a merge blocker.

## Review stance

- Be strict about correctness, authorization, business rules, data consistency,
  typed error handling, and architecture.
- Focus on the branch diff and the behavior it introduces. Do not turn the
  review into a general audit of unrelated existing code.
- Inspect related files when needed to understand an interaction. Reviewing each
  changed file in isolation misses many defects in this repository.
- Prefer a small number of high-confidence findings with evidence over a long
  list of speculative comments.
- Do not nitpick style unless it reflects a repeated inconsistency, violates the
  configured quality gates, or could confuse future maintainers.
- If an issue is likely pre-existing, only call it blocking when this branch
  makes it worse, relies on it incorrectly, or misses a necessary migration path.

## Branch comparison workflow

1. Confirm the target branch. Default to `develop` for this repository.
2. Check the current branch and working tree:
   - `git --no-pager branch --show-current`
   - `git --no-pager status --short`
3. If local branch data may be stale and network access is available, fetch the
   target branch before reviewing. If fetching is not possible, state that the
   review uses the local copy of `develop`.
4. Compare from the merge base, not with a two-dot diff:
   - `git --no-pager log --oneline develop..HEAD`
   - `git --no-pager diff --stat develop...HEAD`
   - `git --no-pager diff --name-status develop...HEAD`
   - `git --no-pager diff develop...HEAD -- <paths>` as needed
5. If the working tree has uncommitted changes, do not silently mix them into the
   branch review. Either exclude them and mention that they were not reviewed, or
   explicitly separate committed branch changes from local uncommitted changes if
   the user asks for both.
6. Read changed files plus the nearest call sites, type definitions, query or
   mutation adapters, route handlers, Prisma models, and UI components needed to
   understand the introduced behavior.
7. If the branch changes dependencies or framework-level behavior, inspect
   `package.json`, `package-lock.json`, and `next.config.ts`, then load
   `references/versioned-practices.md` before judging the implementation.
8. Run targeted validation when feasible. Start with the narrowest relevant
   checks, then consider the full quality gates: `npm run format:check`,
   `npm run lint`, and `npm run build`.

## Optional parallel review fan-out

For small branches, review inline as a single agent. Use parallel sub-agents only
when the branch is broad enough that independent specialist passes are likely to
improve coverage: large diffs, changes across three or more layers, Prisma or
migration changes plus feature code, dependency/deployment changes, or multiple
independent domain flows.

Do not split review by one sub-agent per changed file or component by default.
DefensasFIC defects often cross file boundaries: API route contracts must match
`lib/types/*`, `lib/api/*`, `lib/queries/*`, `lib/mutations/*`, and consuming UI;
selected-term behavior crosses server helpers, provider state, API routes, and
gestor pages; Prisma changes must be reviewed with migrations, DB helpers,
business rules, and deployment behavior. Per-file review creates duplicate
comments, misses cross-layer regressions, and encourages low-confidence nits.

When sub-agents are available, the lead reviewer should first collect common
context and then fan out by review slice. Sub-agents are read-only reviewers:
they should not edit files, post PR comments, commit changes, or run broad
validation unless explicitly assigned.

Include this context in every delegated review task because sub-agents do not see
the parent conversation:

- Repository: DefensasFIC.
- Target branch, default `develop`.
- Current branch and whether uncommitted changes are included or excluded.
- The branch overview from `git --no-pager log --oneline develop..HEAD`,
  `git --no-pager diff --stat develop...HEAD`, and
  `git --no-pager diff --name-status develop...HEAD`.
- The assigned review slice and path-scoped diff command.
- The exact review focus and severity expectations.
- Reminder that the task is read-only.
- `references/versioned-practices.md` when framework, dependency, Prisma, auth,
  validation, or deployment behavior is relevant.

Recommended review slices:

| Slice                     | Use when changed files touch                                                                                                             | Review focus                                                                                                                                                                                                                        |
| ------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Business/RBAC/domain      | `app/**`, `lib/auth/**`, `lib/db/**`, selected-term helpers, defense/evaluation/committee/student/professor flows                        | Role/resource authorization, selected-term scoping, defense lifecycle, committee rules, evaluation rules, `User` vs `AuthIdentity`, data exposure                                                                                   |
| API contracts             | `app/api/**`, `lib/types/**`, `lib/api/**`, `lib/queries/**`, `lib/mutations/**`                                                         | Zod validation for body/query/params/form data, shared request/response types, `ApiError`, error builders, status codes, `apiFetch`/`handleErrorResponse`, `readApiResult`/`writeApiResult`, query invalidation                     |
| Frontend/Next.js/TanStack | `app/**`, `components/**`, `lib/queries/**`, `lib/mutations/**`, styling/config files                                                    | App Router server/client boundaries, smallest `'use client'` scope, serializable props, no client import of server-only code, TanStack Query keys/cancellation/error states, mutation invalidation, responsive Tailwind/token usage |
| Prisma/data consistency   | `prisma/**`, `lib/db/**`, bulk/import/scheduler code, date utilities/types                                                               | Migration safety, uniqueness/indexes, transaction boundaries, race conditions, idempotency, selected-term/ownership query scoping, date branded strings at API/browser boundaries, no Prisma in client-importable modules           |
| Dependency/deployment     | `package.json`, `package-lock.json`, `next.config.ts`, `proxy.ts`, `Dockerfile`, `azure-pipelines.yml`, `scripts/**`, `prisma.config.ts` | Version compatibility, peer dependencies, server/client runtime fit, bundle/build impact, Node 24/npm 11, Azure App Service/Oryx install-build-start flow, Prisma generation/migrations at startup                                  |

Each sub-agent should return only candidate findings:

```markdown
### Slice: <name>

#### Blocking candidates

- `<file-or-symbol>`: <issue>
  - Evidence: <specific diff behavior or call path>
  - Impact: <business/security/data/build impact>
  - Suggested fix: <concrete direction>
  - Confidence: <high|medium|low>

#### Non-blocking candidates

- ...

#### Questions / assumptions

- ...

#### Validation suggested

- <targeted command or scenario>
```

The lead reviewer must synthesize results instead of forwarding raw sub-agent
output:

- Verify every blocking candidate directly against the diff/code before reporting
  it as a blocker.
- De-duplicate overlapping findings by behavior, not by file.
- Combine cross-slice evidence into one stronger finding when separate agents saw
  only part of the issue.
- Resolve conflicts by checking repository conventions, `AGENTS.md`, and
  `references/versioned-practices.md`; if still uncertain, move the concern to
  Questions / assumptions.
- Do not include raw sub-agent output. Report only high-confidence risks that
  matter for merge safety.
- Run expensive validation once from the parent context when feasible.
- The lead reviewer owns the final recommendation: `Approve`,
  `Approve with non-blocking comments`, or `Request changes`.

## Repository-specific review checklist

Use this checklist to guide investigation. A branch does not need comments in
all areas; report only actual risks or important missing verification.

### Product and business rules

Check that the branch preserves the internship defenses MVP scope and the
business rules documented in `AGENTS.md`:

- RBAC boundaries for `Academic`, `Student`, `Gestor` (`Gestor General` and
  `Director de Area`), and `Superadmin`.
- `User` remains the domain person record, while `AuthIdentity` remains the
  optional Microsoft Entra login link.
- Gestor actions are scoped by the selected active academic term when
  appropriate. Server-side access should go through
  `lib/selected-term.server.ts`; client-side gestor UI should go through
  `components/gestor/SelectedTermProvider.tsx`; client mutations should use
  `lib/api/selected-term.ts`.
- Defense state transitions remain explicit:
  `Pending validation -> Published -> Self-assignment closed -> Scheduled -> Evaluated -> Cancelled/Disabled`.
- Committee rules stay enforceable: standard defense = `1 President + 1 Member`;
  double degree = `2 Presidents` plus configured members.
- Evaluation remains president-only, grades stay in `1.0-7.0`, and evaluation is
  enabled only at the scheduled defense time.
- Acta PDF generation and acta version history are not weakened when evaluation
  or defense data changes.

### Next.js, React, and frontend architecture

Review App Router usage and client/server boundaries carefully:

- Keep components as Server Components by default. Use `'use client'` only where
  interactivity, browser APIs, TanStack Query hooks, client state, or lifecycle
  logic are truly required.
- Treat broad client boundaries as performance and data-leakage risks: once a
  file is marked `'use client'`, its imported module graph and directly rendered
  components are included in the client bundle.
- Verify that values passed from Server Components to Client Components are React
  serializable and do not include secrets, Prisma client objects, class
  instances, or other server-only values.
- Avoid `useEffect` for derived state, data transformation, or request lifecycles
  that TanStack Query should own. Use React's guidance from
  `https://react.dev/learn/you-might-not-need-an-effect`.
- Client-side API GET UI state should use `lib/queries/*` with TanStack Query,
  stable query keys, and `readApiResult(signal, apiCall({ signal }))`.
- Client-side writes that affect cached UI state should use `lib/mutations/*`,
  unwrap with `writeApiResult(...)`, and invalidate the relevant query keys.
- `lib/api/*` must stay framework-agnostic: use `apiFetch(...)` and
  `handleErrorResponse(...)`, return `Promise<ApiResult<T>>`, and do not call
  React hooks there.
- Avoid hand-written `useEffect + AbortController` API fetching in components.
- Check loading, empty, error, stale-data, and cancellation states, especially for
  async UI flows, mutations, optimistic updates, and route transitions.
- Do not require Next 16 Cache Components patterns unless the branch enables
  `cacheComponents` in `next.config.ts`. If it does, verify `use cache` scopes,
  serializable cache inputs/outputs, and runtime APIs such as `cookies()` and
  `headers()` are handled according to Next 16 docs.
- Use Tailwind/CSS for responsive presentation. Do not use `window.innerWidth`
  or similar viewport checks for styling/layout that CSS can express.
- UI colors should use tokens from `tailwind.config.ts` such as `carbon-black`,
  `ocean-blue`, and `ghost-white`; avoid hardcoded hex colors in components.

### API routes, contracts, and integrations

For changes under `app/api/**`, `lib/api/**`, `lib/types/**`, `lib/queries/**`,
or `lib/mutations/**`, verify the full contract across layers:

- Route handlers should have explicit return types like
  `Promise<NextResponse<ApiError> | NextResponse<T>>` and use `ApiError` from
  `@/lib/types/api.types`.
- For dynamic route handlers in Next 16, treat `params` as a promise
  (`params: Promise<{ id: string }>` or `RouteContext<'/path/[id]'>`) before
  validating it.
- Validate every input surface with Zod: request body, query string, form data,
  and dynamic path params. Do not manually cast unchecked input.
- JSON request schemas, inferred payload types, and response interfaces belong in
  the relevant `lib/types/*.types.ts` file, not inside `route.ts` or
  `lib/api/*`.
- Prefer shared API error builders from `@/lib/util/api`:
  `unauthorizedError`, `alreadyExistsError`, `fromZodError`, `customError`,
  `internalServerError`, and `DEFAULT_JSON_PARSING_ERROR`.
- Protected route handlers should use `auth(...)` and authorization helpers such
  as `requireRole(...)` with the appropriate role constants.
- For NextAuth v5 and Next 16, preserve the existing `proxy.ts` pattern and the
  split between edge-safe auth config and database-backed server auth config. Do
  not rely on Proxy as the only authorization layer.
- If a branch introduces Server Actions/Server Functions, verify this is an
  intentional architectural choice rather than an accidental bypass of the
  repo's API-route + TanStack mutation boundary, and check authorization,
  validation, and cache/UI invalidation at the action boundary.
- Status codes should match behavior: validation errors `400`, auth failures
  `401/403` according to existing helpers, missing resources `404`, conflicts
  `409`, and unexpected failures `500` with generic client-facing messages.
- Check for breaking changes to existing response shapes consumed by UI, query
  hooks, or external clients.
- For authenticated API client calls that require bearer tokens, validate the
  token first and return `Err({ message: BaseError.MissingToken })` before
  making the request.

### TypeScript, errors, and layering

- Prefer `interface` for object shapes. Use `type` aliases for unions, inferred
  Zod payloads, function-like shapes, or cases interfaces cannot model cleanly.
- Avoid `any`. Keep type-only imports consistent with ESLint.
- Business and database helpers that can fail should expose explicit error
  results where this repository already does so: `Result` / `ResultAsync` from
  `ts-results`, `safeDbCall(...)`, `ApiResult<T>`, `DbError`, or route-local
  typed errors.
- Avoid throwing generic errors from business logic. Throwing is acceptable at a
  boundary that intentionally converts `ApiResult` into React Query errors
  (`readApiResult` / `writeApiResult`) or follows an established framework
  convention.
- Check that callers handle both success and failure. Silent `void` promises,
  swallowed errors, and generic catch blocks are high-risk under the strict
  ESLint rules.

### Prisma, database, and data consistency

- Keep Prisma access in `lib/db/*` or other established server-only modules.
- Server-only modules that could be accidentally imported by client code should
  use the existing `import 'server-only'` marker pattern.
- Use `safeDbCall(...)` / typed database results where existing code does.
- Verify query scoping for role, selected term, user identity, area, and defense
  ownership. Authorization-sensitive queries should not fetch broader data and
  filter only in the UI.
- Use `select`/`include` deliberately. Avoid returning sensitive or unnecessary
  fields.
- Look for missing transactions when multiple writes must succeed or fail
  together, especially around term creation, roster imports, committee changes,
  evaluation, acta history, and state transitions.
- Check unique constraints, race conditions, idempotency, and conflict handling
  around create/update/delete flows.
- If `prisma/schema.prisma` or migrations changed, review migration safety,
  generated client implications, existing data compatibility, and deployment
  behavior under Azure App Service/Oryx.
- Date-only, clock-time, and timestamp values should remain branded strings at
  API/browser boundaries. Convert to `Date` only at Prisma or true instant
  formatting boundaries via `@util/date`.

### Dependency and library review

- Treat new runtime dependencies as architectural changes. A branch should not add
  a library only because a blog post recommends it; it should solve a repeated
  problem better than the repo's existing helpers and match the resolved package
  versions.
- If the branch adds or upgrades a library, check peer dependencies, Next/React
  compatibility, server/client runtime compatibility, bundle impact, Azure/Oryx
  deployment impact, and whether the package is needed during production install,
  build, or startup.
- Prefer existing patterns first: `@/lib/util/api` for request parsing,
  `lib/types/*` for Zod contracts, `lib/api/*` for transport, `lib/queries/*` and
  `lib/mutations/*` for TanStack Query, `lib/db/*` for Prisma, and shared
  selected-term helpers for active-term state.
- See `references/versioned-practices.md` before recommending or approving
  optional libraries such as `server-only`/`client-only`, `zod-form-data`,
  `@t3-oss/env-nextjs`, `nuqs`, or Server Action helper libraries.

### Deployment and build compatibility

- Preserve Node.js 24 / npm 11 compatibility from `package.json`.
- Do not break Oryx/App Service production flow. The repository expects
  production deployment through `npm install --production`, `npm run build`, and
  `npm run start` unless an intentional deployment change is documented.
- Treat changes to `package.json`, build scripts, Prisma generation, startup, or
  migrations as high-risk because they can affect Azure App Service restarts.
- Never approve committed secrets, `.env` content, or credentials.

## Severity guidance

Use **Blocking issues** for defects that should be fixed before merge:

- Incorrect business behavior or invalid domain state.
- Broken authorization, authentication, selected-term scoping, or data exposure.
- Data integrity risks, missing transactionality, unsafe migrations, or race
  conditions likely to affect real users.
- API contract changes that break existing callers without migration handling.
- TypeScript/build/lint failures that are likely from the branch.
- Next.js/client-server architecture violations that create hydration issues,
  stale data, unhandled async flows, or maintainability problems.

Use **Non-blocking issues** for improvements that are worth doing but do not
make the branch unsafe to merge: naming clarity, small duplication, missing
minor validation messages, localized maintainability improvements, or tests that
would improve confidence for low-risk behavior.

If a concern is speculative, place it under **Questions / assumptions** instead
of presenting it as a defect.

## Expected output

Return a structured code review in this exact shape:

```markdown
### Summary

<Briefly describe what the branch introduces and the overall risk level: low,
medium, or high. Mention whether validation was run and, when framework/library
best practices mattered, which installed versions or docs were checked.>

### Blocking issues

- `<file-or-symbol>`: <issue title>
  - Why it matters: <business/user/data/build impact>
  - Evidence: <specific diff behavior, call path, or relevant code reference>
  - Suggested fix: <concrete fix direction>

If there are no blocking issues, write: `None found.`

### Non-blocking issues

- `<file-or-symbol>`: <improvement and why it helps>

If there are no non-blocking issues, write: `None found.`

### Questions / assumptions

- <unclear product rule, missing context, version mismatch, or assumption to
  confirm>

If there are no questions, write: `None.`

### Tests to add or verify

- <specific test, scenario, or quality gate>

### Final recommendation

<Approve | Approve with non-blocking comments | Request changes>
```

## Final recommendation rules

- Use `Request changes` when there is any blocking issue.
- Use `Approve with non-blocking comments` when there are no blockers but there
  are worthwhile non-blocking improvements, missing tests for meaningful behavior,
  or validation could not be run for an important path.
- Use `Approve` only when the branch appears safe, follows repository
  conventions, and relevant validation has passed or the lack of validation is
  clearly low-risk.
