---
name: commit-layer-plan
description: Plan a layered git commit sequence for the current worktree without creating commits. Use this skill whenever the user asks how to split changes into commits, wants a commit plan before opening a PR, asks for a clean git history, wants to group edited files by logical concern or dependency, or says things like "how should I commit this", "split this into layered commits", "prepare commit commands", or "organize my branch history".
compatibility:
  tools: Bash, Read, Glob, Grep
---

# Commit Layer Planner

Analyze the current branch changes and propose a clean commit sequence that the user can run manually.

Why this skill exists: a good PR history is easier to review when foundational changes land first, feature behavior comes next, and follow-up docs/tests/refactors are separated instead of mixed into one large commit.

## Core rule

Do not create commits yourself.

Your job is to inspect the worktree, infer the logical layers, and output the exact commands the user should run.

## What to inspect

Start by gathering the branch state:

1. Run `git status --short` to see modified, staged, and untracked files.
2. Run `git diff --stat` and `git diff` to understand the full change set.
3. Run `git diff --cached --stat` and `git diff --cached` if anything is already staged.
4. Run `git log --oneline -10` to learn the repository's commit style.
5. If the branch purpose matters, inspect `git diff <base-branch>...HEAD --stat` when the base branch is known or can be safely inferred.

Read files only when the diff alone is not enough to understand whether two changes belong together.

## How to group commits

Build commits around meaning, not around directories alone.

Prefer this order:

1. Foundations: schema, shared types, low-level utilities, reusable helpers.
2. Domain logic: API routes, database logic, services, state transitions.
3. UI or consumer updates that depend on the earlier layers.
4. Tests, docs, fixtures, or cleanup that support the earlier commits.

Keep files together when one change does not make sense without the other.
Split files apart when they represent separate reviewable concerns even if they touched the same feature.

Good reasons to keep files in the same commit:

- a Prisma schema change and the code that must compile against it
- a route contract and the shared type it introduces
- a helper plus the single caller that only exists because of that helper

Good reasons to split files into later commits:

- tests that merely validate already-reviewable production code
- docs or copy changes after behavior is implemented
- refactors that are not required for the main fix or feature
- formatting churn mixed with logic changes

## Layering heuristics

When deciding the sequence, favor the smallest stack where each commit leaves the tree understandable.

- Put shared contracts before code that consumes them.
- Put backend behavior before frontend code that depends on new data.
- Put generated files with the source change that requires them, unless the repo convention says otherwise.
- Keep migrations with the schema or database layer they belong to.
- Avoid commits that would obviously fail lint/typecheck unless the repo routinely tolerates that during intermediate steps.

If the current worktree contains unrelated changes, call that out explicitly and leave them out of the proposed commands unless the user clearly asked for everything.

## Commit message guidance

Follow the repository's recent commit style when possible.

Default to concise imperative messages such as:

- `defense: bootstrap committee slots on creation`
- `bulk: keep imported defenses as placeholders`
- `gestor: show empty committee slots`

Focus the message on why that layer exists, not just a file list.

## Command format

For each proposed commit, output:

- a short label for the layer
- why those files belong together
- the file list
- the exact command block the user should run

Use explicit `git add -- <file>... && git commit -m "..."` commands. Do not use interactive git commands. The `--` separator is required before pathspecs so Git cannot interpret a file path as an option, and it makes generated commands more robust when paths include route segment syntax or other shell-sensitive characters.

Quote every path in command blocks with single quotes, even if it looks simple. This keeps generated commands safe to paste into shells such as zsh and bash, where route segment names like `[id]`, wildcard characters such as `*` or `?`, spaces, parentheses, and other metacharacters can be expanded before Git receives them. Leave the human-readable `Files:` list unquoted for readability.

Example command path quoting:

```bash
git add -- 'app/api/v1/professor/defenses/[id]/inscription/route.ts' 'lib/types/professor-defense.types.ts' && git commit -m "professors: add defense assignment flows"
```

If a commit depends on partial-file staging and there is no safe file-level split, say so clearly instead of inventing a command.

## Output format

Use this plain-text structure:

```text
Commit 1: <label>
Why: <1-2 sentences>
Files:
- path/a
- path/b
Command:
git add -- 'path/a' 'path/b' && git commit -m "scope: message"

Commit 2: <label>
Why: <1-2 sentences>
Files:
- path/c
Command:
git add -- 'path/c' && git commit -m "scope: message"

Notes:
- <optional blockers, unrelated files, or partial-staging warnings>
```

## Safety notes

- Never run `git commit`, `git add`, `git reset`, or any other mutating git command as part of this skill.
- Never hide ambiguity. If one file mixes two concerns, say that partial staging or a code split is needed.
- Never suggest committing likely secret files such as `.env` without an explicit warning.
- Prefer a smaller number of meaningful commits over a long list of tiny mechanical ones.

## Example prompts

- `Help me split my current branch into layered commits before I open the PR.`
- `Based on the files I changed, give me the commit commands I should run.`
- `I worked on schema, API, and UI changes. Propose a clean commit order without actually committing.`
