# Azure Repos PR Comments Reference

Load this reference from the `azure-repos-pr` skill when the user asks to read,
summarize, address, post, reply to, update, or inspect Azure DevOps PR comments.
Keep `SKILL.md` as the routing guide and use this file for exact Azure CLI/REST
details.

## Contents

- [Use cases](#use-cases)
- [Required inputs](#required-inputs)
- [Azure CLI setup](#azure-cli-setup)
- [REST mapping](#rest-mapping)
- [Resolve repository ID](#resolve-repository-id)
- [Create a PR-level comment](#create-a-pr-level-comment)
- [Create a file/line review comment](#create-a-fileline-review-comment)
- [Read PR comments](#read-pr-comments)
- [Normalize actionable comments](#normalize-actionable-comments)
- [Address review comments with code changes](#address-review-comments-with-code-changes)
- [Reply to an existing thread](#reply-to-an-existing-thread)
- [Update thread status](#update-thread-status)
- [List existing threads](#list-existing-threads)
- [Operational rules](#operational-rules)
- [Minimal helper](#minimal-helper)

## Use cases

Use `az devops invoke` for Azure Repos PR comments because the Azure CLI
`az repos pr` command group supports PR operations such as create, show, update,
reviewers, policies, votes, and work items, but does not expose a native
comment command.

Supported comment workflows:

- PR-level conversation comment: create a pull request thread with no
  `threadContext`.
- File/line review comment: create a pull request thread with `threadContext`.
- Read comments: list all pull request threads or get one thread by ID.
- Address comments: normalize active review threads, map them to repo files and
  lines, make the requested changes, validate, and optionally reply or resolve.
- Reply to an existing review thread: create a comment under an existing thread.
- Update thread status: mark a thread fixed, closed, active, or another
  supported status.
- List threads: inspect existing comments before replying or to verify posting.

Reference docs:

- <https://learn.microsoft.com/en-us/cli/azure/repos/pr?view=azure-cli-latest>
- <https://learn.microsoft.com/en-us/cli/azure/devops?view=azure-cli-latest>
- <https://learn.microsoft.com/en-us/rest/api/azure/devops/git/pull-request-threads/create?view=azure-devops-rest-7.1>
- <https://learn.microsoft.com/en-us/rest/api/azure/devops/git/pull-request-threads/get?view=azure-devops-rest-7.1>
- <https://learn.microsoft.com/en-us/rest/api/azure/devops/git/pull-request-thread-comments/create?view=azure-devops-rest-7.1>
- <https://learn.microsoft.com/en-us/rest/api/azure/devops/git/pull-request-threads/list?view=azure-devops-rest-7.1>
- <https://learn.microsoft.com/en-us/rest/api/azure/devops/git/pull-request-threads/update?view=azure-devops-rest-7.1>

## Required inputs

For every comment workflow, collect or resolve:

```bash
ORG_URL="https://dev.azure.com/<organization>"
PROJECT="<project-name-or-id>"
PR_ID="<pull-request-id>"
REPOSITORY_ID="<target-repository-id>"
```

For posting or replying, also collect:

```bash
COMMENT_BODY="<markdown comment text>"
```

For file/line comments, also collect:

```bash
FILE_PATH="/path/from/repo/root"
DIFF_SIDE="right" # right for added/modified lines, left for deleted/old lines
START_LINE="42"
END_LINE="42" # optional; default to START_LINE for a single-line comment
```

Use a leading slash in `FILE_PATH` unless the local Azure Repos instance proves a
different path convention is required.

## Azure CLI setup

Use the `azure-devops` extension:

```bash
az extension add --name azure-devops --upgrade
```

Authenticate before invoking Azure DevOps APIs. In non-interactive contexts, use
a PAT that can write PR comments. The REST docs list `vso.code_write` and
`vso.threads_full` as relevant scopes for PR threads.

```bash
printf '%s' "$AZURE_DEVOPS_EXT_PAT" | az devops login \
  --organization "$ORG_URL"
```

Configure defaults when the user gives stable organization/project context:

```bash
az devops configure --defaults \
  organization="$ORG_URL" \
  project="$PROJECT"
```

## REST mapping

PR comment threads map to the Azure DevOps Git REST API:

```http
GET https://dev.azure.com/{organization}/{project}/_apis/git/repositories/{repositoryId}/pullRequests/{pullRequestId}/threads?api-version=7.1
```

```http
GET https://dev.azure.com/{organization}/{project}/_apis/git/repositories/{repositoryId}/pullRequests/{pullRequestId}/threads/{threadId}?api-version=7.1
```

```http
POST https://dev.azure.com/{organization}/{project}/_apis/git/repositories/{repositoryId}/pullRequests/{pullRequestId}/threads?api-version=7.1
```

```http
PATCH https://dev.azure.com/{organization}/{project}/_apis/git/repositories/{repositoryId}/pullRequests/{pullRequestId}/threads/{threadId}?api-version=7.1
```

Use this `az devops invoke` shape:

```bash
az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
  --api-version 7.1 \
  --http-method POST \
  --in-file "$BODY_FILE" \
  -o json
```

Use API version `7.1` for the PR thread endpoints.

## Resolve repository ID

Prefer repository ID over repository name:

```bash
REPOSITORY_ID="$(az repos pr show \
  --id "$PR_ID" \
  --organization "$ORG_URL" \
  --project "$PROJECT" \
  --query "repository.id" \
  -o tsv)"
```

If Azure DevOps defaults are configured, `--organization` and `--project` may be
unnecessary. Keep them explicit when available.

## Create a PR-level comment

Use this when the comment belongs in the PR conversation, not on a specific
file/line.

Body:

```json
{
  "comments": [
    {
      "parentCommentId": 0,
      "content": "This new feature looks good!",
      "commentType": 1
    }
  ],
  "status": 1
}
```

Command:

```bash
BODY_FILE="$(mktemp)"

jq -n --arg content "$COMMENT_BODY" '{
  comments: [
    {
      parentCommentId: 0,
      content: $content,
      commentType: 1
    }
  ],
  status: 1
}' > "$BODY_FILE"

az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
  --api-version 7.1 \
  --http-method POST \
  --in-file "$BODY_FILE" \
  -o json

rm -f "$BODY_FILE"
```

Expected result: the response contains a top-level thread `id`, `status:
"active"`, `threadContext: null`, and the submitted comment. Save the top-level
`id` when the user may need a reply or follow-up action.

## Create a file/line review comment

Use this when the comment should attach to a changed file and line in the PR
diff. Validate that the line exists on the chosen side of the PR diff before
posting.

Right-side comment body:

```json
{
  "comments": [
    {
      "parentCommentId": 0,
      "content": "Should we add a comment about what this value means?",
      "commentType": 1
    }
  ],
  "status": 1,
  "threadContext": {
    "filePath": "/src/app.ts",
    "leftFileStart": null,
    "leftFileEnd": null,
    "rightFileStart": {
      "line": 42,
      "offset": 1
    },
    "rightFileEnd": {
      "line": 42,
      "offset": 1
    }
  }
}
```

Command for right-side added/modified lines:

```bash
BODY_FILE="$(mktemp)"
END_LINE="${END_LINE:-$START_LINE}"

jq -n \
  --arg content "$COMMENT_BODY" \
  --arg filePath "$FILE_PATH" \
  --argjson startLine "$START_LINE" \
  --argjson endLine "$END_LINE" \
  '{
    comments: [
      {
        parentCommentId: 0,
        content: $content,
        commentType: 1
      }
    ],
    status: 1,
    threadContext: {
      filePath: $filePath,
      leftFileStart: null,
      leftFileEnd: null,
      rightFileStart: {
        line: $startLine,
        offset: 1
      },
      rightFileEnd: {
        line: $endLine,
        offset: 1
      }
    }
  }' > "$BODY_FILE"

az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
  --api-version 7.1 \
  --http-method POST \
  --in-file "$BODY_FILE" \
  -o json

rm -f "$BODY_FILE"
```

For deleted/old lines, switch to left-side positions:

```json
"threadContext": {
  "filePath": "/src/app.ts",
  "leftFileStart": {
    "line": 42,
    "offset": 1
  },
  "leftFileEnd": {
    "line": 45,
    "offset": 1
  },
  "rightFileStart": null,
  "rightFileEnd": null
}
```

Line numbers are 1-based. For creating full-line comments through
`az devops invoke`, use `offset: 1`; Azure Repos can reject `offset: 0` for
file/line thread creation. Use exact character offsets only when they are known
from a diff parser and accepted by Azure DevOps.

## Read PR comments

Use this when the user asks to read, summarize, inspect, or address Azure Repos
PR comments.

List all PR threads:

```bash
az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
  --api-version 7.1 \
  --http-method GET \
  -o json
```

Get one thread by ID:

```bash
THREAD_ID="<thread-id>"

az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
      threadId="$THREAD_ID" \
  --api-version 7.1 \
  --http-method GET \
  -o json
```

Optional tracking parameters:

```bash
az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
  --query-parameters \
      '$iteration'="$RIGHT_ITERATION" \
      '$baseIteration'="$LEFT_ITERATION" \
  --api-version 7.1 \
  --http-method GET \
  -o json
```

Use iteration parameters only when the user needs positions tracked to a
specific diff iteration. For normal review handling, the plain list call is the
default.

## Normalize actionable comments

Convert Azure thread JSON into a stable shape before summarizing or editing
code. Default to active, non-deleted human text comments:

```bash
az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
  --api-version 7.1 \
  --http-method GET \
  -o json |
jq '[
  .value[]
  | select(.isDeleted != true)
  | select(.status == "active" or .status == "pending")
  | . as $thread
  | $thread.comments[]
  | select(.isDeleted != true)
  | select(.commentType == "text")
  | {
      threadId: $thread.id,
      threadStatus: $thread.status,
      commentId: .id,
      parentCommentId: .parentCommentId,
      author: .author.displayName,
      publishedDate: .publishedDate,
      updatedDate: .lastUpdatedDate,
      filePath: $thread.threadContext.filePath,
      rightStartLine: $thread.threadContext.rightFileStart.line,
      rightEndLine: $thread.threadContext.rightFileEnd.line,
      leftStartLine: $thread.threadContext.leftFileStart.line,
      leftEndLine: $thread.threadContext.leftFileEnd.line,
      content: .content
    }
]'
```

Interpret the normalized fields this way:

- `filePath == null`: PR-level conversation comment.
- `filePath != null`: file/line review comment.
- `rightStartLine/rightEndLine`: source-branch side for added or modified code.
- `leftStartLine/leftEndLine`: target-branch side for deleted or old code.
- `parentCommentId == 0`: first comment in the thread.
- `parentCommentId != 0`: reply to an earlier comment.

For read-only summaries, group comments as:

- PR-level comments first.
- File/line comments grouped by `filePath`, then line range.
- Replies nested under their thread, preserving chronological order when needed.

Do not treat `commentType: "system"` or `commentType: "codeChange"` as a review
request unless the user asks for the full PR timeline.

## Address review comments with code changes

Use this workflow when the user asks to fix, address, handle, or apply PR
comments:

1. Read and normalize active comments.
2. Check out the PR source branch safely. Do not switch branches with a dirty
   worktree.
3. For each file/line comment, inspect the current file and nearby context. PR
   comments may move across iterations, so validate the concern against current
   code instead of blindly editing the original line number.
4. Treat PR-level comments as general requirements or review notes.
5. Make the smallest code or documentation changes that address the comment.
6. Run the repo-appropriate validation commands for the changed files.
7. Summarize each addressed thread ID and the corresponding change.
8. Reply to threads or mark them fixed only when the user asks or when the
   repository workflow clearly expects it.

If a comment is ambiguous, stale, or no longer applies, do not guess. Report the
thread ID and ask for clarification or explain why no code change was made.

## Reply to an existing thread

Use `pullRequestThreadComments` for replies:

```http
POST https://dev.azure.com/{organization}/{project}/_apis/git/repositories/{repositoryId}/pullRequests/{pullRequestId}/threads/{threadId}/comments?api-version=7.1
```

Command:

```bash
THREAD_ID="<thread-id>"
PARENT_COMMENT_ID="${PARENT_COMMENT_ID:-1}"
BODY_FILE="$(mktemp)"

jq -n \
  --arg content "$COMMENT_BODY" \
  --argjson parentCommentId "$PARENT_COMMENT_ID" \
  '{
    content: $content,
    parentCommentId: $parentCommentId,
    commentType: 1
  }' > "$BODY_FILE"

az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreadComments \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
      threadId="$THREAD_ID" \
  --api-version 7.1 \
  --http-method POST \
  --in-file "$BODY_FILE" \
  -o json

rm -f "$BODY_FILE"
```

For a reply to the first comment in a thread, `parentCommentId` is commonly `1`.
If listing threads shows a different comment ID, use the listed ID.

## Update thread status

Use this only when the user asks to resolve, close, reopen, or otherwise update
thread state after reading or addressing comments.

Supported status values in Azure DevOps include `active`, `fixed`, `wontFix`,
`closed`, `byDesign`, and `pending`. Use `fixed` for review feedback addressed
by a change. Use `closed` only when the repo convention prefers closing rather
than fixed.

```bash
THREAD_ID="<thread-id>"
THREAD_STATUS="fixed"
BODY_FILE="$(mktemp)"

jq -n --arg status "$THREAD_STATUS" '{
  status: $status
}' > "$BODY_FILE"

az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
      threadId="$THREAD_ID" \
  --api-version 7.1 \
  --http-method PATCH \
  --in-file "$BODY_FILE" \
  -o json

rm -f "$BODY_FILE"
```

## List existing threads

List all PR threads:

```bash
az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
  --api-version 7.1 \
  --http-method GET \
  -o json
```

List active human text comments with `jq`:

```bash
az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
  --api-version 7.1 \
  --http-method GET \
  -o json |
jq '.value[]
    | select(.status == "active")
    | {
        threadId: .id,
        filePath: .threadContext.filePath,
        comments: [.comments[] | select(.commentType == "text") | {id, parentCommentId, content}]
      }'
```

## Operational rules

- Use `--in-file`, not inline JSON, for comment bodies.
- Use `commentType: 1` and `status: 1` when creating text/active threads.
- Use `GET pullRequestThreads` to read all PR comments.
- Use `GET pullRequestThreads` with `threadId` to read one thread.
- Normalize comments before turning them into summaries or file edits.
- Use right-side positions for added or modified lines.
- Use left-side positions only for deleted or old lines.
- Store the returned top-level thread `id`.
- Ask for missing Azure DevOps context instead of guessing organization,
  project, repository, or PR ID.
- Do not post file/line comments when the target line cannot be validated in the
  PR diff. Use a PR-level comment or ask for a corrected location.
- Do not mark threads fixed or closed unless the user asks or the repo workflow
  clearly expects it.

## Minimal helper

This helper posts PR-level comments and right-side file/line comments. Extend it
for left-side deleted-line comments only when needed.

```bash
post_azure_pr_comment() {
  local org_url="$1"
  local project="$2"
  local repository_id="$3"
  local pr_id="$4"
  local content="$5"
  local file_path="${6:-}"
  local start_line="${7:-}"
  local end_line="${8:-}"

  local body_file
  body_file="$(mktemp)"

  if [ -z "$file_path" ]; then
    jq -n --arg content "$content" '{
      comments: [
        {
          parentCommentId: 0,
          content: $content,
          commentType: 1
        }
      ],
      status: 1
    }' > "$body_file"
  else
    if [ -z "$start_line" ]; then
      echo "start_line is required for file/line comments" >&2
      rm -f "$body_file"
      return 2
    fi

    if [ -z "$end_line" ]; then
      end_line="$start_line"
    fi

    jq -n \
      --arg content "$content" \
      --arg filePath "$file_path" \
      --argjson startLine "$start_line" \
      --argjson endLine "$end_line" \
      '{
        comments: [
          {
            parentCommentId: 0,
            content: $content,
            commentType: 1
          }
        ],
        status: 1,
        threadContext: {
          filePath: $filePath,
          leftFileStart: null,
          leftFileEnd: null,
          rightFileStart: {
            line: $startLine,
            offset: 1
          },
          rightFileEnd: {
            line: $endLine,
            offset: 1
          }
        }
      }' > "$body_file"
  fi

  az devops invoke \
    --organization "$org_url" \
    --area git \
    --resource pullRequestThreads \
    --route-parameters \
        project="$project" \
        repositoryId="$repository_id" \
        pullRequestId="$pr_id" \
    --api-version 7.1 \
    --http-method POST \
    --in-file "$body_file" \
    -o json

  local rc=$?
  rm -f "$body_file"
  return "$rc"
}
```
