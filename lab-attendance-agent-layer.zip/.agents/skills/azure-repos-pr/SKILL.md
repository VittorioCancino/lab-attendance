---
name: azure-repos-pr
description: Manage Azure Repos pull request workflows with the Azure CLI, including creating PRs and reading, addressing, or posting PR review comments. Use this skill whenever the user wants to open, create, or publish a PR in Azure DevOps/Azure Repos, generate a PR title and description from a branch diff, read or summarize PR comments, address review feedback with code changes, post a simple PR conversation comment, add a file/line review comment, reply to an existing PR thread, or mentions `az repos pr create`, `az devops invoke`, Azure DevOps PR comments, Azure Repos review comments, or fixing PR comments.
---

# Azure Repos PR Workflow

Create pull requests in Azure Repos with `az repos pr create`, and read,
address, or post PR conversation and review comments with `az devops invoke`
against the Azure DevOps Git REST API.

Why this skill exists: PR creation and PR comment handling are mechanical Azure
CLI operations, but they require enough repository context, JSON parsing, and
payload shaping that agents should follow one consistent workflow.

## Capabilities

- Create an Azure Repos pull request from a source branch to a target branch.
- Generate a PR title and description from the branch diff before creating the
  PR.
- Read and summarize PR-level and file/line review comments.
- Address active PR review comments with code or documentation changes.
- Post a simple PR conversation comment.
- Post a file/line review comment on the right or left side of a PR diff.
- Reply to, list, or update existing PR comment threads when needed.

## Azure CLI dependencies

Use Bash with Azure CLI and the `azure-devops` extension. Use `az repos pr` for
pull request creation and PR metadata. Use `az devops invoke` for PR comment
threads because the `az repos pr` command group does not provide a comment
subcommand.

## Required inputs for PR creation

- `source branch`
- `target branch`

If either branch is missing, ask for it before doing anything else.

## Required inputs for PR comment actions

- `pull request ID`
- comment action: read, summarize, address, post, reply, update status, or list

For reading, summarizing, or addressing comments, also determine whether to read
all threads, active unresolved threads only, a specific thread ID, or a specific
file path.

For posting or replying to comments, also require:

- `comment body`
- comment scope: PR-level conversation comment, file/line review comment, or
  reply

For file/line review comments, also require:

- repository file path
- side of the diff: `right` for added/modified lines, `left` for deleted/old
  lines
- start line and, for multi-line comments, end line

If Azure DevOps organization, project, or repository cannot be detected from the
repo/defaults, ask for the missing values. Prefer resolving the repository ID
from `az repos pr show --id <PR_ID>` instead of using the repository name.

## Repository conventions

In this repository:

- feature and fix branches usually target `develop`
- hotfix branches usually target `main`

Use that as a hint if the user seems unsure, but do not silently guess when the branch matters. The source and target branches are explicit inputs for this skill.

## PR creation workflow

1. Confirm the branch inputs.
2. Run `git branch --show-current`.
3. If the current branch already matches the source branch, continue.
4. If it does not match:
   - Run `git status --short`.
   - If the worktree is clean, switch to the source branch so `pr-description` can analyze the correct branch.
   - If the worktree is dirty, do not switch branches automatically. Tell the user you need the source branch checked out, or permission to handle it another way.
5. Ensure the source branch exists remotely before creating the PR. If it is not pushed yet, ask before pushing it.
6. Load and use the `pr-description` skill with the target branch to generate the PR title and description.
7. Parse the `pr-description` output like this:
   - the first line after `Title:` becomes the Azure PR title
   - everything after the blank line becomes the Azure PR description
8. Create the PR with `az repos pr create`.
9. Return the PR URL, PR ID, source branch, target branch, and final title.

## PR comment read/address workflow

Read `references/comments.md` before reading, summarizing, addressing, posting,
replying to, or listing PR comments. It contains the exact `az devops invoke`
area/resource mapping, request body shapes, normalization filters, and file/line
positioning rules for Azure DevOps PR threads.

1. Confirm the PR ID and whether the user wants a summary only or wants code
   changes made from review comments.
2. Resolve or confirm Azure DevOps organization, project, and repository ID.
3. Read PR threads with `az devops invoke --http-method GET`.
4. Normalize thread JSON into actionable items: thread ID, status, file path,
   side, line range, author, comment ID, parent comment ID, and content.
5. Ignore deleted comments and system/code-change comments unless the user asks
   for the full timeline. Default to active human text comments.
6. For summary-only requests, report the actionable comments grouped by PR-level
   feedback and file/line feedback.
7. For address requests, ensure the PR source branch is checked out safely, map
   each actionable file/line comment to the current workspace, make the requested
   changes, run relevant validation, and summarize what was addressed.
8. Reply to handled threads only when the user asks, or when the task explicitly
   includes responding to reviewers.
9. Mark threads fixed or closed only when the user asks or repository convention
   clearly expects it.

## PR comment write workflow

1. Confirm the PR ID, comment body, and comment scope.
2. Resolve or confirm Azure DevOps organization, project, and repository ID.
3. For file/line comments, confirm the file path, diff side, and line range.
4. Validate file/line positions against the PR diff when possible. If the line
   is uncertain or not in the PR diff, post a PR-level comment instead or ask
   the user for the correct location.
5. Build the request body in a temporary JSON file. Prefer `jq` or another
   structured JSON writer when comment content contains quotes, Markdown, or
   newlines.
6. Post with `az devops invoke --area git --resource pullRequestThreads`
   using `--in-file`.
7. Return the created thread ID and where the comment was posted.

## Azure CLI command for PR creation

Prefer this shape:

```bash
az repos pr create \
  --detect true \
  --source-branch "<source-branch>" \
  --target-branch "<target-branch>" \
  --title "<title>" \
  --description "<description>" \
  --output json
```

Use `--detect true` first so Azure DevOps organization, project, and repository can be inferred from the current repo when available. If detection fails, ask the user for the missing Azure DevOps context or use values they already provided.

Do not use `--open` unless the user explicitly wants the browser opened.

## Azure CLI command for reading PR comments

Do not parse raw Azure thread JSON ad hoc in final answers. Load
`references/comments.md`, use the list/get command shapes there, and normalize
comments before summarizing or making code changes.

```bash
az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
  --api-version 7.1 \
  --http-method GET \
  -o json
```

For a single thread, use `--resource pullRequestThreads` with
`threadId="$THREAD_ID"` in `--route-parameters`.

## Azure CLI command for writing PR comments

Do not guess the REST payload from memory. Load `references/comments.md` for the
current body shape and use this command shape:

```bash
az devops invoke \
  --organization "$ORG_URL" \
  --area git \
  --resource pullRequestThreads \
  --route-parameters \
      project="$PROJECT" \
      repositoryId="$REPOSITORY_ID" \
      pullRequestId="$PR_ID" \
  --api-version 7.1 \
  --http-method POST \
  --in-file "$BODY_FILE" \
  -o json
```

Use `pullRequestThreadComments` instead of `pullRequestThreads` only when
replying to an existing thread.

## Safety checks

- Do not switch branches if there are uncommitted changes.
- Do not push the source branch unless the user asked you to create the PR and the push is required to complete that request.
- Do not invent the PR title or description manually when `pr-description` can analyze the branch correctly.
- If the repo is not configured for Azure DevOps detection, ask for the missing org, project, or repository instead of guessing.
- Do not make code changes from PR comments until the source branch for that PR
  is checked out safely.
- Do not treat system comments, vote changes, deleted comments, or closed/fixed
  threads as actionable review requests unless the user explicitly asks for all
  comments.
- Do not post file/line comments without enough confidence that the position
  exists on the selected side of the PR diff.
- Do not inline ad hoc JSON in shell commands for comments. Use `--in-file` so
  Markdown and quoted text are preserved.

## Output

For a created PR, report the result in plain text using this structure:

```text
PR created: <url>
PR ID: <id>
Branches: <source-branch> -> <target-branch>
Title: <title>
```

For a posted PR comment, report the result in plain text using this structure:

```text
PR comment posted: <thread-id>
Scope: <conversation|file-line|reply>
Location: <pr-level|path:line-range>
```

If the operation fails, explain the blocking error directly and say what input,
auth scope, Azure DevOps context, or repo state is missing.

For read/comment-addressing requests, report the result in plain text using this
structure:

```text
PR comments read: <count>
Actionable: <count>
Addressed: <count|not requested>
Validation: <commands run or not run>
```

## Example prompts

- `Create an Azure Repos PR from feature/123-selected-term-switcher into develop.`
- `Open a PR in Azure DevOps from hotfix/login-loop to main and generate the title/body from the diff.`
- `Use az repos pr create to open a PR from fix/456-token-refresh to develop.`
- `Post a PR comment on Azure DevOps PR 391 saying the rollout notes are missing.`
- `Add a review comment on PR 391 at app/api/users/route.ts line 42 asking for Zod validation.`
- `Reply to Azure Repos PR 391 thread 147 with "Addressed in the latest commit."`
- `Read the active review comments on Azure Repos PR 391 and summarize the requested changes.`
- `Address the reviewer comments on PR 391, commit the fixes, and reply to each handled thread.`
