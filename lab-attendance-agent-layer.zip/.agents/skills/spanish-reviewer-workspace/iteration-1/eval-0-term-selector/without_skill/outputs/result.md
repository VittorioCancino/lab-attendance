```tsx
export function TermSelector({ termName, onChange }: Props) {
  return (
    <section aria-label="Selector de período académico">
      <h2>Seleccione el período académico</h2>
      <p>
        Elija el período en el que desea trabajar. Si no selecciona un período,
        no podrá continuar.
      </p>
      <button onClick={onChange}>Cambiar período</button>
      <p>Período activo: {termName}</p>
    </section>
  );
}
```

**Changed Files**

- `components/gestor/TermSelector.tsx`: Corrected Spanish accents and wording in user-facing text only.
