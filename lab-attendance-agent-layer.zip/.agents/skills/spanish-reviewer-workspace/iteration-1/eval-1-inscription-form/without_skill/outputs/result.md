```tsx
const messages = {
  required: 'Debe ingresar un correo electrónico válido.',
  upload: 'Suba su informe en formato PDF.',
  success: 'Su inscripción fue actualizada correctamente.',
  error: 'Ocurrió un error al guardar. Intente nuevamente más tarde.',
};

export default function Page() {
  return (
    <form>
      <label htmlFor="email">Correo electrónico del estudiante</label>
      <input id="email" placeholder="Ingrese su correo institucional" />
      <button>Enviar postulación</button>
    </form>
  );
}
```

Changed files:

- `app/(dashboard)/inscripcion/page.tsx`: Corrected Spanish copy for formal Chilean university users, including accents, grammar, tone, and PDF capitalization.
