Corrected snippets:

```ts
return NextResponse.json(
  { message: 'No tiene permisos para realizar esta acción' },
  { status: 403 },
);
return NextResponse.json(
  { error: 'No se pudieron cargar las defensas. Inténtelo nuevamente.' },
  { status: 500 },
);
```

```tsx
export function DefenseEmptyState({ areaName }: { areaName: string }) {
  return (
    <div>
      <h3>No hay defensas disponibles</h3>
      <p>Aún no existen defensas publicadas para el área {areaName}.</p>
      <a href="/gestor/defensas">Volver atrás</a>
    </div>
  );
}
```

Changed files:

- app/api/defensas/route.ts
- components/DefenseEmptyState.tsx

I can show the detailed text changes if you want.
