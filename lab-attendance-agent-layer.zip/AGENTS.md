# Repository Guidelines

## Collaboration and Review Gates

- Use English for agent interactions, status updates, explanations, and
  developer collaboration.
- Write all user-facing application copy in formal Latin American Spanish with
  correct spelling, accents, grammar, and punctuation.
- Develop the project in explicit, reviewable checkpoints. Before each
  checkpoint, state its scope and any decisions required from the user.
- Implement only the approved checkpoint. Report changed files and validation
  results, then stop until the user approves the next checkpoint.
- Ask before making an architectural or product decision that expands or
  changes the approved scope. Do not silently choose a new direction.
- Prefer the smallest correct change. Do not scaffold future features or add
  abstractions without a concrete requirement in the current checkpoint.
- Follow this initial sequence unless the user changes it: guardrails -> app
  scaffold -> schema review -> schema implementation -> authentication ->
  invitations and memberships -> QR attendance -> interfaces -> stabilization.

## Product Scope and Core Rules

- The MVP lets lab managers see who is currently in a lab and review attendance
  history. Attendees record arrival and departure through self-service QR scans.
- One deployed application instance represents exactly one lab. Multiple
  deployments share one PostgreSQL database while keeping lab data isolated.
- Resolve the current lab on the server from the required
  `LAB_INSTANCE_SLUG` environment variable. A deployment must fail closed when
  the configured lab is missing, unknown, disabled, or ambiguous, except during
  an explicitly enabled first-start bootstrap.
- A `User` is a global person/account and may belong to multiple labs. Do not
  duplicate a person solely because they use more than one lab.
- A lab membership connects a user to a lab and supplies the lab-specific role.
  The initial lab roles are `MANAGER` and `ATTENDEE`. A global administrator is
  a separate account capability, not another lab membership role.
- A global administrator may enter any deployed instance, but every deployment
  still exposes and queries only its configured lab. Do not add a cross-lab
  control plane without explicit approval.
- Managers invite users to their lab. Public registration and unrestricted lab
  enrollment are outside the MVP.
- Authentication uses local credentials. Do not add Microsoft Entra ID,
  OpenID Connect, or another external identity provider unless explicitly
  approved later.
- One attendance visit has a server-recorded check-in time and an optional
  server-recorded checkout time. At most one open visit may exist per user and
  lab.
- Attendee self-service check-in and checkout require a rotating QR code. An
  authorized manager may record an explicit manual transition, and the system
  may close an open visit at the configured operating-hours boundary. Scanning
  the same QR token more than once must be idempotent rather than immediately
  reversing the first action.
- Scheduled classes, geolocation tracking, biometric identity, public signup,
  and cross-lab switching inside one deployment are non-goals for the MVP.

## Tenant Isolation

- Treat `Lab` as the tenant and application-instance boundary.
- Never trust a browser-supplied lab ID for authorization or query scoping.
  Resolve the lab from trusted server configuration for every request.
- Every tenant-owned table must carry `labId`. Use compound foreign keys and
  unique constraints where possible so the database also rejects cross-lab
  relationships.
- Every tenant-owned query and mutation must include the trusted `labId`. Avoid
  fetching a tenant-owned record by globally unique record ID and authorizing it
  only after data has already been returned.
- Membership and role checks must include both `userId` and the current
  `labId`. A normal global account alone never grants access to a lab; an active
  global administrator is the only approved exception.
- Sessions must be bound to the current lab. A session issued by one deployment
  must not authorize access in another deployment without a membership check.
- Add integration tests proving that users, managers, invitations, QR tokens,
  visits, and reports from Lab A cannot be read or changed through Lab B.
- All deployments share one migration history. Run production migrations once
  through a controlled deployment step, not concurrently from every app
  instance at startup.

## Data and Domain Integrity

- The initial domain concepts are `Lab`, `User`, `LabMembership`,
  `LabInvitation`, `AttendanceVisit`, and `AttendanceScan`. Review exact schema
  changes and generated SQL before applying each migration.
- Normalize emails consistently and enforce the approved uniqueness behavior at
  the database level.
- Store password hashes and invitation-token hashes, never plaintext passwords
  or raw invitation tokens.
- Invitation tokens must be single-use, expiring, lab-bound, and invalid after
  acceptance or revocation.
- Enforce one open attendance visit per user and lab with a PostgreSQL
  constraint or partial unique index, not only an application-level check.
- Process attendance scans transactionally. Concurrent scans must not create
  duplicate open visits, multiple checkouts, or contradictory scan records.
- Store event timestamps in UTC using server time. Convert them to the lab's
  configured IANA timezone only for display and calendar grouping.
- Preserve attendance history. Prefer disabling memberships or accounts over
  cascading deletion that silently removes historical visits.
- Use database constraints for invariants and application validation for clear
  user feedback; do not rely on either layer alone.

## Authentication and Security

- Use an established authentication/session library and an established password
  hashing implementation. Prefer Argon2id unless the selected library has a
  documented, equally appropriate default.
- Keep authentication cookies HTTP-only, secure in production, and appropriately
  SameSite-scoped. Never expose session secrets to client components.
- Treat session claims as identity and instance context, not durable proof of a
  current role. Re-read active membership and role for authorization-sensitive
  operations.
- Require either a valid membership in the configured lab or an active global
  administrator capability before completing login or serving protected data.
- Gate automatic lab and administrator registration behind
  `INSTANCE_BOOTSTRAP_ENABLED=true`. After first registration, disable the flag
  so normal startups only validate the lab.
- Bootstrap must preserve existing lab metadata and user credentials and promote
  the configured global administrator transactionally. It must not create a lab
  membership for that account; global administrators create lab managers later.
- Treat `LAB_BOOTSTRAP_ADMIN_INITIAL_PASSWORD` only as the creation credential
  for a missing account. If the global user already exists, never overwrite its
  password from any instance environment.
- Return generic login, invitation, and authorization errors to clients. Do not
  reveal whether an email exists or log passwords, session values, raw invite
  tokens, QR tokens, or password hashes.
- Rate-limit credential verification, invitation acceptance, and attendance
  scanning before production deployment.

## QR Attendance Rules

- Only an authenticated manager of the current lab may create or revoke a QR
  display authorization. A display with a valid, lab-bound authorization may
  request and show rotating QR codes without receiving a user session or access
  to a protected panel.
- Display activation codes must be single-use and short-lived. Display sessions
  must expire, be revocable, and remain valid only while the authorizing manager,
  membership, and lab are active.
- Generate QR tokens on the server. Tokens must be signed, short-lived, bound to
  the current lab, and validated using server time.
- A QR token proves recent physical access to the displayed code; it does not
  replace user authentication or membership authorization.
- Require a valid QR token for attendee self-service check-in and checkout.
  Authorized manager transitions and automatic operating-hours closures are the
  only non-QR attendance transitions and must be recorded with their respective
  `MANAGER` or `SYSTEM` method.
- Record each user's consumption of a QR token with a uniqueness constraint so
  repeated submissions return the original result without toggling attendance.
- Determine check-in versus checkout from the user's current open visit inside
  the same database transaction that records the scan.
- Reject tampered, expired, disabled-lab, cross-lab, or otherwise invalid tokens.
  Do not include token contents in logs or analytics.
- Use server-generated timestamps for attendance. Never accept authoritative
  check-in or checkout timestamps from the browser.

## Project Structure

- Use Next.js App Router under `app/`; do not introduce the Pages Router.
- Keep reusable UI in `components/`, with feature-specific components grouped by
  domain when that improves navigation.
- Keep authentication and authorization helpers in `lib/auth/`.
- Keep trusted current-lab resolution and tenant context in `lib/tenant/`.
- Keep Prisma-backed domain queries and transactions in `lib/db/`.
- Keep shared request, response, and domain contracts in `lib/types/`, and keep
  Zod schemas close to the contracts or feature they validate.
- Create `lib/api/` only for browser-facing transport functions. Keep those
  functions framework-agnostic and free of React hooks.
- Create `lib/queries/` and `lib/mutations/` only for flows that actually use
  TanStack Query; do not add empty architectural layers during scaffolding.
- Keep reusable constants in `lib/const/` and general-purpose helpers in
  `lib/util/`. Do not turn either directory into an unrelated catch-all.
- Keep the Prisma schema and migrations under `prisma/`. Generated Prisma files
  must never be edited manually.
- Keep automated tests under `tests/` or colocated where the selected test setup
  expects them. Use one consistent convention after scaffolding.

## Next.js and Data Flow

- Use Server Components by default. Add `'use client'` only at the smallest leaf
  boundary that needs browser state, effects, or event handlers.
- Server Components may call typed server/domain modules directly. Do not route
  server-only reads through an internal HTTP request.
- Use Server Actions for straightforward authenticated form mutations when they
  keep the flow simpler. Apply the same Zod validation, tenant resolution, and
  authorization rules used by route handlers.
- Use Route Handlers for QR scanning, browser API access, polling, and endpoints
  that require an explicit HTTP contract.
- Use TanStack Query when client-side server state benefits from polling,
  cancellation, caching, invalidation, or optimistic updates. Do not require it
  for data rendered entirely by Server Components.
- Do not implement request lifecycle management with handwritten
  `useEffect + fetch + AbortController` when TanStack Query or a Server Component
  is the appropriate model.
- Do not mandate `ts-results` or another result-wrapper abstraction. Introduce
  one only after a concrete repeated error-handling need is demonstrated and
  approved.
- Validate every untrusted input with Zod, including JSON bodies, form data,
  query parameters, dynamic path parameters, environment variables, invite
  tokens, and decoded QR claims.
- Define shared JSON contracts outside `route.ts` and browser components. Keep
  route handler return types explicit and error payloads consistent.
- Use explicit caching semantics for server reads. Attendance, membership, and
  authorization-sensitive data must not be served from an unsafe stale cache.
- Keep direct external-service calls in dedicated server modules rather than
  scattering `fetch` calls across pages and components.

## Coding Style

- Use strict TypeScript and small, typed modules. Avoid `any`; prefer type-only
  imports where applicable.
- Prefer `interface` for object shapes and `type` for unions, intersections, and
  shapes an interface cannot express cleanly.
- Once present, review `eslint.config.ts` before writing application code and
  comply with the active rules rather than suppressing them.
- Use Prettier with 2 spaces, single quotes, semicolons, trailing commas, and an
  80-column print width unless the scaffolded configuration explicitly differs.
- Use `PascalCase` for components, camelCase for functions and variables, and
  lowercase route folders.
- Prefer configured import aliases over long relative imports. Do not assume an
  alias exists before it is added to `tsconfig.json`.
- Keep Prisma imports and database access out of client-importable modules.
- Add comments only to explain a non-obvious reason, invariant, or tradeoff. Do
  not add comments that merely restate or organize the code.
- Do not add backward-compatibility branches without a concrete persisted-data,
  external-consumer, or shipped-behavior requirement.

## Frontend and Spanish Copy

- Use the `spanish-reviewer` skill for user-facing copy reviews. Preserve formal
  Latin American Spanish and consistent attendance terminology.
- Build accessible interfaces with semantic HTML, keyboard support, visible
  focus states, associated labels, and status announcements where appropriate.
- Ensure attendee scanning and check-in/out confirmation work well on mobile;
  ensure manager presence and history views work on desktop and mobile.
- Prefer CSS and Tailwind for responsive presentation. Do not use
  `window.innerWidth` or equivalent JavaScript checks for layout behavior that
  media queries can express.
- Once design tokens are established, use them consistently and avoid arbitrary
  hardcoded colors in components.
- Provide clear loading, empty, success, expired-token, authorization, and error
  states without exposing internal details.

## Commands and Quality Gates

- Treat `package.json` scripts as the command source of truth after scaffolding.
- Expected workflows are `npm install`, `npm run dev`, `npm run format:check`,
  `npm run lint`, `npm test`, and `npm run build`; adjust this list in the
  guardrails if the approved scaffold chooses different script names.
- Provide explicit Prisma scripts for client generation, development migrations,
  production migration deployment, and database inspection.
- Before completing an application-code checkpoint, run the relevant focused
  tests plus formatting, linting, type/build checks that exist at that stage.
- Before release, the minimum quality gate is formatting, linting, automated
  tests, and a successful production build.
- Test tenant isolation, role checks, invitation expiry and reuse, QR signature
  and expiry, scan idempotency, concurrent scans, and visit lifecycle behavior.
- Keep production start commands non-interactive and restart-safe, but remain
  deployment-platform neutral until the user approves a target.

## Git and Pull Requests

- Keep commits small, cohesive, and imperative when the user asks for commits.
  Do not create commits, push branches, or open pull requests without an explicit
  request.
- Never discard, overwrite, or revert unrelated user changes. Avoid destructive
  Git commands unless the user explicitly approves them.
- The local agent layer is intentionally ignored by Git. Do not force-add
  `.agents/`, `.claude/`, `AGENTS.md`, or `CLAUDE.md`.
- Use provider-specific PR skills only when the user confirms that provider. Do
  not assume Azure Repos or a deployment platform from the copied agent tools.
- PR summaries should explain behavior, tenant/security impact, validation, and
  screenshots for user-interface changes.

## Configuration and Deployment

- Keep secrets in ignored environment files and maintain a safe `.env.example`
  containing names and non-secret descriptions only.
- Keep `DATABASE_URL`, authentication secrets, QR-signing secrets, and instance
  configuration server-only. Use `NEXT_PUBLIC_*` only for values intentionally
  exposed to every browser.
- Minimize personally identifiable information in logs. Use structured logging
  for authentication outcomes, manager actions, and attendance errors without
  logging credentials or tokens.
- Remain deployment-platform neutral until a deployment checkpoint is reviewed.
- Back up shared production data and review migration SQL before destructive or
  irreversible schema changes.

## Other

- Check `README.md` and current configuration files before changing established
  commands or architecture.
- The project-specific skills copied from DefensasFIC require a separate review
  before they can be treated as authoritative for this application.
- For Next.js implementation guidance, use
  `.agents/skills/nextjs-developer/`, but prefer these repository rules whenever
  copied skill guidance conflicts with the lab-attendance architecture.
